# Database saturation comparison

Backend **search**. Started 2026-10-15T20:24:35.69901322Z.

independent OS client processes send one record per native call or streaming SDK RPC; native FindOne/ReplaceOne or single-ID mget/PUT; no client aggregation; worker-owned disjoint IDs; common phase barriers and unchanged pools across warmup and measurement; alternating AB/BA; latency is each business request including validation, queueing and any server aggregation; independent persisted postflight; Search uses explicit refresh_interval=1s, translog.durability=request, one primary and zero replicas; sustained database CPU requires >=5 intervals, >=80% measurement coverage, mean CPU>=threshold and CPU>=threshold during >=80% measurement duration in every round, plus <=10% next-level throughput gain.

Warmup 1m0s and measurement 1m0s per path/stage, 3 paired rounds, requested writes 100%.

Complete business-request budget for both paths: 10s.

4 independent OS client processes. Each worker sends one business request containing one record, waits for its acknowledged result, and validates it. p50/p95/p99 describe individual requests; histograms are pooled rather than averaging process quantiles.

| Batch | Workers | Round | Path | Read | Write | Success | Errors/unknown | Ops/s | p95 call ms | DB CPU budget % | Full CPU time % | Sampling coverage % | Verified |
| ---: | ---: | ---: | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | --- |
| 1 | 256 | 1 | direct | 0 | 7437 | 7437 | 0 | 121.7 | 2883.583 | 103.7 | 100.0 | 100.0 | true |
| 1 | 256 | 1 | weir | 0 | 118656 | 118656 | 0 | 1971.1 | 327.679 | 103.6 | 97.3 | 97.3 | true |
| 1 | 256 | 2 | direct | 0 | 38131 | 38131 | 0 | 633.3 | 655.359 | 104.0 | 98.6 | 98.6 | true |
| 1 | 256 | 2 | weir | 0 | 191387 | 191387 | 0 | 3184.4 | 212.991 | 103.6 | 100.0 | 100.0 | true |
| 1 | 256 | 3 | direct | 0 | 40546 | 40546 | 0 | 673.1 | 589.823 | 103.8 | 99.9 | 99.9 | true |
| 1 | 256 | 3 | weir | 0 | 306335 | 306335 | 0 | 5103.8 | 114.687 | 103.8 | 99.9 | 99.9 | true |
| 1 | 512 | 1 | direct | 0 | 40931 | 40931 | 0 | 677.5 | 1048.575 | 103.4 | 97.8 | 99.6 | true |
| 1 | 512 | 1 | weir | 0 | 312852 | 312852 | 0 | 5197.6 | 212.991 | 103.6 | 99.2 | 99.2 | true |
| 1 | 512 | 2 | direct | 0 | 42246 | 42246 | 0 | 695.8 | 917.503 | 103.9 | 98.7 | 98.7 | true |
| 1 | 512 | 2 | weir | 0 | 322905 | 322905 | 0 | 5379.0 | 212.991 | 103.6 | 98.4 | 98.4 | true |
| 1 | 512 | 3 | direct | 0 | 42010 | 42010 | 0 | 695.3 | 1048.575 | 104.0 | 98.8 | 98.8 | true |
| 1 | 512 | 3 | weir | 0 | 347719 | 347719 | 0 | 5794.2 | 212.991 | 103.9 | 98.3 | 98.3 | true |
| 1 | 1024 | 1 | direct | 0 | 41379 | 41379 | 0 | 680.2 | 1966.079 | 102.8 | 96.8 | 98.5 | true |
| 1 | 1024 | 1 | weir | 0 | 352620 | 352620 | 0 | 5780.8 | 425.983 | 103.8 | 98.4 | 98.4 | true |
| 1 | 1024 | 2 | direct | 0 | 40824 | 40824 | 0 | 671.0 | 1835.007 | 103.7 | 99.4 | 99.4 | true |
| 1 | 1024 | 2 | weir | 0 | 362916 | 362916 | 0 | 6027.8 | 327.679 | 103.7 | 98.7 | 98.7 | true |
| 1 | 1024 | 3 | direct | 0 | 41174 | 41174 | 0 | 676.3 | 1835.007 | 104.0 | 98.9 | 98.9 | true |
| 1 | 1024 | 3 | weir | 0 | 360451 | 360451 | 0 | 5997.6 | 327.679 | 103.8 | 99.5 | 99.5 | true |

Measured Weir adapter and streaming RPC evidence (warmup, reset and postflight excluded):

| Batch | Workers | Round | Adapter invocations | Mean adapter batch | Execute RPCs | Queue mean ms | Adapter mean ms | Rejections |
| ---: | ---: | ---: | ---: | ---: | --- | ---: | ---: | ---: |
| 1 | 256 | 1 | 927 | 128.000 | 118656 | 4.013 | 117.491 | 0 |
| 1 | 256 | 2 | 1498 | 127.762 | 191387 | 3.997 | 68.059 | 0 |
| 1 | 256 | 3 | 2394 | 127.959 | 306335 | 4.167 | 38.121 | 0 |
| 1 | 512 | 1 | 2451 | 127.643 | 312852 | 5.333 | 79.122 | 0 |
| 1 | 512 | 2 | 2533 | 127.479 | 322905 | 5.406 | 75.406 | 0 |
| 1 | 512 | 3 | 2725 | 127.603 | 347719 | 5.345 | 68.745 | 0 |
| 1 | 1024 | 1 | 2824 | 124.865 | 352620 | 5.967 | 147.090 | 0 |
| 1 | 1024 | 2 | 2904 | 124.971 | 362916 | 6.167 | 141.285 | 0 |
| 1 | 1024 | 3 | 2899 | 124.336 | 360451 | 5.996 | 142.138 | 0 |

**Batch 1 at demonstrated database CPU saturation:** direct 689.5 logical ops/s (512 workers), Weir 5456.7 logical ops/s (512 workers), Weir/direct 7.9137, change +691.37%.

Best verified business QPS within this ladder: direct 689.5 (512 workers), Weir 5934.7 (1024 workers), observed change +760.69%. This is a measured business-throughput comparison, not a maximum-database-capacity claim.

Observed single-request business performance at matched client concurrency (independent of the database-capacity qualification):

| Workers | Direct QPS | Weir QPS | Change | Direct p50/p95/p99 ms | Weir p50/p95/p99 ms |
| ---: | ---: | ---: | ---: | --- | --- |
| 256 | 474.3 | 3418.2 | +620.63% | 393.215 / 2097.151 / 2621.439 | 57.343 / 212.991 / 327.679 |
| 512 | 689.5 | 5456.7 | +691.37% | 720.895 / 983.039 / 1310.719 | 81.919 / 212.991 / 425.983 |
| 1024 | 675.8 | 5934.7 | +778.14% | 1572.863 / 1835.007 / 2359.295 | 147.455 / 360.447 / 589.823 |

These QPS and latency observations apply to this hardware and measured concurrency range. A business-throughput improvement can exist without demonstrating the maximum database capacity. An underfull database or missing next-level plateau keeps the database-capacity comparison unavailable.

Aggregation evidence: the JSON records one business request per record, Execute RPC counts, adapter invocation counts, average adapter batch and its cumulative histogram, and RPCs per adapter invocation. An adapter invocation is not necessarily one physical database wire command. MongoDB physical find/update/bulkWrite/getMore/killCursors/commitTransaction/abortTransaction deltas come from owned serverStatus at timed boundaries; missing counters remain unavailable. Elasticsearch has no equivalent physical HTTP-command counter. Every child PID, configured native pool limit, final revision ranges, exit result and sampled CPU/RSS is retained; coordinator sampling CPU is excluded from business-client CPU.

The JSON retains before/after raw public Weir metrics and their observed deltas, every resource sample, monitor failures, raw cumulative database/container I/O and network counters, CPU quota/host core denominator, and client/Weir cumulative CPU. Docker CPU uses cumulative Engine usage and read timestamps across each entire sampling interval, never CLI instantaneous percentages. Both interval endpoints must succeed; missing intervals reduce full-run coverage. Samples include monitoring traffic and background database work. Native ps CPU has platform-dependent clock resolution. Native databases share the host CPU budget with the client and Weir. Disk/network utilization or capacity is not inferred from byte counters. A plateau without sustained database CPU saturation is not a database-full-load result. Startup/discovery/reset/postflight and warmup are excluded from throughput; all in-flight completion and validation is included.

Resource observation schema 2 additionally retains bounded Linux host CPU ticks (busy, idle, iowait and steal, without double-counted guest ticks), CPU/IO/memory pressure, the sampler's allowed CPU list and runtime parallelism, Docker cumulative throttling counters, fixed sampled Store queue/execution gauges, and projected Search write-pool/indexing-pressure/GC statistics. Host/device evidence includes other runner work; sampler affinity is not a promise that all child processes have that affinity. Missing or unsupported fields remain explicitly unavailable. Pure Search stages retain before/after effective index settings and owned-index indexing/refresh/merge/flush/translog statistics, with explicit 1s refresh and request durability. Lucene flush statistics are not counts or timings of per-request translog fsync. No added metric alone establishes database or storage capacity.
