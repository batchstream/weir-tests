# Database saturation comparison

Backend **search**. Started 2026-10-15T18:16:05.811599528Z.

independent OS client processes send one record per native call or streaming SDK RPC; native FindOne/ReplaceOne or single-ID mget/PUT; no client aggregation; worker-owned disjoint IDs; common phase barriers and unchanged pools across warmup and measurement; alternating AB/BA; latency is each business request including validation, queueing and any server aggregation; independent persisted postflight; Search uses explicit refresh_interval=1s, translog.durability=request, one primary and zero replicas; sustained database CPU requires >=5 intervals, >=80% measurement coverage, mean CPU>=threshold and CPU>=threshold during >=80% measurement duration in every round, plus <=10% next-level throughput gain.

Warmup 30s and measurement 30s per path/stage, 3 paired rounds, requested writes 0%.

Complete business-request budget for both paths: 10s.

4 independent OS client processes. Each worker sends one business request containing one record, waits for its acknowledged result, and validates it. p50/p95/p99 describe individual requests; histograms are pooled rather than averaging process quantiles.

| Batch | Workers | Round | Path | Read | Write | Success | Errors/unknown | Ops/s | p95 call ms | DB CPU budget % | Full CPU time % | Sampling coverage % | Verified |
| ---: | ---: | ---: | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | --- |
| 1 | 4 | 1 | direct | 130050 | 0 | 130050 | 0 | 4334.8 | 1.151 | 100.0 | 97.2 | 97.2 | true |
| 1 | 4 | 1 | weir | 48985 | 0 | 48985 | 0 | 1632.7 | 3.583 | 72.9 | 0.0 | 97.5 | true |
| 1 | 4 | 2 | direct | 152482 | 0 | 152482 | 0 | 5082.4 | 0.959 | 99.7 | 96.6 | 96.6 | true |
| 1 | 4 | 2 | weir | 49095 | 0 | 49095 | 0 | 1636.4 | 3.583 | 72.2 | 0.0 | 97.6 | true |
| 1 | 4 | 3 | direct | 153479 | 0 | 153479 | 0 | 5115.7 | 0.959 | 99.9 | 96.6 | 96.6 | true |
| 1 | 4 | 3 | weir | 49061 | 0 | 49061 | 0 | 1635.2 | 3.583 | 71.9 | 0.0 | 97.5 | true |
| 1 | 128 | 1 | direct | 221862 | 0 | 221862 | 0 | 7393.3 | 49.151 | 99.9 | 99.0 | 99.0 | true |
| 1 | 128 | 1 | weir | 150122 | 0 | 150122 | 0 | 5001.7 | 45.055 | 52.0 | 0.0 | 99.5 | true |
| 1 | 128 | 2 | direct | 222475 | 0 | 222475 | 0 | 7413.7 | 49.151 | 100.0 | 99.0 | 99.0 | true |
| 1 | 128 | 2 | weir | 150302 | 0 | 150302 | 0 | 5007.7 | 45.055 | 50.9 | 0.0 | 99.3 | true |
| 1 | 128 | 3 | direct | 232325 | 0 | 232325 | 0 | 7741.5 | 45.055 | 100.0 | 99.0 | 99.0 | true |
| 1 | 128 | 3 | weir | 150807 | 0 | 150807 | 0 | 5025.3 | 45.055 | 49.8 | 0.0 | 99.5 | true |

Measured Weir adapter and streaming RPC evidence (warmup, reset and postflight excluded):

| Batch | Workers | Round | Adapter invocations | Mean adapter batch | Execute RPCs | Queue mean ms | Adapter mean ms | Rejections |
| ---: | ---: | ---: | ---: | ---: | --- | ---: | ---: | ---: |
| 1 | 4 | 1 | 47705 | 1.027 | 48985 | 0.016 | 1.541 | 0 |
| 1 | 4 | 2 | 47875 | 1.025 | 49095 | 0.016 | 1.534 | 0 |
| 1 | 4 | 3 | 47858 | 1.025 | 49061 | 0.016 | 1.533 | 0 |
| 1 | 128 | 1 | 22188 | 6.766 | 150122 | 1.421 | 8.523 | 0 |
| 1 | 128 | 2 | 22391 | 6.713 | 150302 | 1.444 | 8.550 | 0 |
| 1 | 128 | 3 | 22232 | 6.783 | 150807 | 1.456 | 8.374 | 0 |

**Batch 1: database-full-load throughput comparison unavailable.** both paths must independently demonstrate sustained database CPU saturation and a verified next-level throughput plateau; increase concurrency or isolate client/Weir resources; I/O/network-bound saturation needs additional device/link capacity evidence.

Best verified business QPS within this ladder: direct 7516.2 (128 workers), Weir 5011.6 (128 workers), observed change -33.32%. This is a measured business-throughput comparison, not a maximum-database-capacity claim.

Observed single-request business performance at matched client concurrency (independent of the database-capacity qualification):

| Workers | Direct QPS | Weir QPS | Change | Direct p50/p95/p99 ms | Weir p50/p95/p99 ms |
| ---: | ---: | ---: | ---: | --- | --- |
| 4 | 4844.3 | 1634.8 | -66.25% | 0.703 / 1.023 / 2.559 | 2.559 / 3.583 / 4.607 |
| 128 | 7516.2 | 5011.6 | -33.32% | 13.311 / 45.055 / 53.247 | 24.575 / 45.055 / 57.343 |

These QPS and latency observations apply to this hardware and measured concurrency range. A business-throughput improvement can exist without demonstrating the maximum database capacity. An underfull database or missing next-level plateau keeps the database-capacity comparison unavailable.

Aggregation evidence: the JSON records one business request per record, Execute RPC counts, adapter invocation counts, average adapter batch and its cumulative histogram, and RPCs per adapter invocation. An adapter invocation is not necessarily one physical database wire command. MongoDB physical find/update/bulkWrite/getMore/killCursors/commitTransaction/abortTransaction deltas come from owned serverStatus at timed boundaries; missing counters remain unavailable. Elasticsearch has no equivalent physical HTTP-command counter. Every child PID, configured native pool limit, final revision ranges, exit result and sampled CPU/RSS is retained; coordinator sampling CPU is excluded from business-client CPU.

The JSON retains before/after raw public Weir metrics and their observed deltas, every resource sample, monitor failures, raw cumulative database/container I/O and network counters, CPU quota/host core denominator, and client/Weir cumulative CPU. Docker CPU uses cumulative Engine usage and read timestamps across each entire sampling interval, never CLI instantaneous percentages. Both interval endpoints must succeed; missing intervals reduce full-run coverage. Samples include monitoring traffic and background database work. Native ps CPU has platform-dependent clock resolution. Native databases share the host CPU budget with the client and Weir. Disk/network utilization or capacity is not inferred from byte counters. A plateau without sustained database CPU saturation is not a database-full-load result. Startup/discovery/reset/postflight and warmup are excluded from throughput; all in-flight completion and validation is included.

Resource observation schema 2 additionally retains bounded Linux host CPU ticks (busy, idle, iowait and steal, without double-counted guest ticks), CPU/IO/memory pressure, the sampler's allowed CPU list and runtime parallelism, Docker cumulative throttling counters, fixed sampled Store queue/execution gauges, and projected Search write-pool/indexing-pressure/GC statistics. Host/device evidence includes other runner work; sampler affinity is not a promise that all child processes have that affinity. Missing or unsupported fields remain explicitly unavailable. Pure Search stages retain before/after effective index settings and owned-index indexing/refresh/merge/flush/translog statistics, with explicit 1s refresh and request durability. Lucene flush statistics are not counts or timings of per-request translog fsync. No added metric alone establishes database or storage capacity.
