# Database saturation comparison

Backend **search**. Started 2026-10-15T18:02:54.922349688Z.

independent OS client processes send one record per native call or streaming SDK RPC; native FindOne/ReplaceOne or single-ID mget/PUT; no client aggregation; worker-owned disjoint IDs; common phase barriers and unchanged pools across warmup and measurement; alternating AB/BA; latency is each business request including validation, queueing and any server aggregation; independent persisted postflight; Search uses explicit refresh_interval=1s, translog.durability=request, one primary and zero replicas; sustained database CPU requires >=5 intervals, >=80% measurement coverage, mean CPU>=threshold and CPU>=threshold during >=80% measurement duration in every round, plus <=10% next-level throughput gain.

Warmup 30s and measurement 30s per path/stage, 3 paired rounds, requested writes 0%.

Complete business-request budget for both paths: 10s.

4 independent OS client processes. Each worker sends one business request containing one record, waits for its acknowledged result, and validates it. p50/p95/p99 describe individual requests; histograms are pooled rather than averaging process quantiles.

| Batch | Workers | Round | Path | Read | Write | Success | Errors/unknown | Ops/s | p95 call ms | DB CPU budget % | Full CPU time % | Sampling coverage % | Verified |
| ---: | ---: | ---: | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | --- |
| 1 | 4 | 1 | direct | 120460 | 0 | 120460 | 0 | 4015.1 | 1.151 | 99.9 | 97.7 | 97.7 | true |
| 1 | 4 | 1 | weir | 47512 | 0 | 47512 | 0 | 1583.6 | 3.839 | 73.2 | 0.0 | 97.8 | true |
| 1 | 4 | 2 | direct | 145334 | 0 | 145334 | 0 | 4844.1 | 1.023 | 99.8 | 96.6 | 96.6 | true |
| 1 | 4 | 2 | weir | 48660 | 0 | 48660 | 0 | 1621.9 | 3.583 | 73.7 | 0.0 | 97.4 | true |
| 1 | 4 | 3 | direct | 148638 | 0 | 148638 | 0 | 4954.3 | 0.959 | 99.8 | 96.5 | 96.5 | true |
| 1 | 4 | 3 | weir | 48493 | 0 | 48493 | 0 | 1616.3 | 3.583 | 73.4 | 0.0 | 97.6 | true |
| 1 | 128 | 1 | direct | 206658 | 0 | 206658 | 0 | 6886.4 | 49.151 | 100.0 | 98.9 | 98.9 | true |
| 1 | 128 | 1 | weir | 146614 | 0 | 146614 | 0 | 4884.6 | 53.247 | 53.5 | 0.0 | 99.4 | true |
| 1 | 128 | 2 | direct | 213034 | 0 | 213034 | 0 | 7099.5 | 49.151 | 100.0 | 98.9 | 98.9 | true |
| 1 | 128 | 2 | weir | 147797 | 0 | 147797 | 0 | 4924.6 | 53.247 | 53.1 | 0.0 | 99.8 | true |
| 1 | 128 | 3 | direct | 217361 | 0 | 217361 | 0 | 7243.4 | 49.151 | 100.0 | 99.0 | 99.0 | true |
| 1 | 128 | 3 | weir | 148312 | 0 | 148312 | 0 | 4942.1 | 49.151 | 52.3 | 0.0 | 99.6 | true |

Measured Weir adapter and streaming RPC evidence (warmup, reset and postflight excluded):

| Batch | Workers | Round | Adapter invocations | Mean adapter batch | Execute RPCs | Queue mean ms | Adapter mean ms | Rejections |
| ---: | ---: | ---: | ---: | ---: | --- | ---: | ---: | ---: |
| 1 | 4 | 1 | 46324 | 1.026 | 47512 | 0.017 | 1.595 | 0 |
| 1 | 4 | 2 | 47394 | 1.027 | 48660 | 0.016 | 1.556 | 0 |
| 1 | 4 | 3 | 47297 | 1.025 | 48493 | 0.016 | 1.562 | 0 |
| 1 | 128 | 1 | 22356 | 6.558 | 146614 | 1.384 | 7.688 | 0 |
| 1 | 128 | 2 | 22383 | 6.603 | 147797 | 1.384 | 7.749 | 0 |
| 1 | 128 | 3 | 22167 | 6.691 | 148312 | 1.361 | 7.796 | 0 |

**Batch 1: database-full-load throughput comparison unavailable.** both paths must independently demonstrate sustained database CPU saturation and a verified next-level throughput plateau; increase concurrency or isolate client/Weir resources; I/O/network-bound saturation needs additional device/link capacity evidence.

Best verified business QPS within this ladder: direct 7076.5 (128 workers), Weir 4917.1 (128 workers), observed change -30.52%. This is a measured business-throughput comparison, not a maximum-database-capacity claim.

Observed single-request business performance at matched client concurrency (independent of the database-capacity qualification):

| Workers | Direct QPS | Weir QPS | Change | Direct p50/p95/p99 ms | Weir p50/p95/p99 ms |
| ---: | ---: | ---: | ---: | --- | --- |
| 4 | 4604.5 | 1607.3 | -65.09% | 0.703 / 1.023 / 6.143 | 2.559 / 3.583 / 4.607 |
| 128 | 7076.5 | 4917.1 | -30.52% | 13.311 / 49.151 / 53.247 | 24.575 / 53.247 / 61.439 |

These QPS and latency observations apply to this hardware and measured concurrency range. A business-throughput improvement can exist without demonstrating the maximum database capacity. An underfull database or missing next-level plateau keeps the database-capacity comparison unavailable.

Aggregation evidence: the JSON records one business request per record, Execute RPC counts, adapter invocation counts, average adapter batch and its cumulative histogram, and RPCs per adapter invocation. An adapter invocation is not necessarily one physical database wire command. MongoDB physical find/update/bulkWrite/getMore/killCursors/commitTransaction/abortTransaction deltas come from owned serverStatus at timed boundaries; missing counters remain unavailable. Elasticsearch has no equivalent physical HTTP-command counter. Every child PID, configured native pool limit, final revision ranges, exit result and sampled CPU/RSS is retained; coordinator sampling CPU is excluded from business-client CPU.

The JSON retains before/after raw public Weir metrics and their observed deltas, every resource sample, monitor failures, raw cumulative database/container I/O and network counters, CPU quota/host core denominator, and client/Weir cumulative CPU. Docker CPU uses cumulative Engine usage and read timestamps across each entire sampling interval, never CLI instantaneous percentages. Both interval endpoints must succeed; missing intervals reduce full-run coverage. Samples include monitoring traffic and background database work. Native ps CPU has platform-dependent clock resolution. Native databases share the host CPU budget with the client and Weir. Disk/network utilization or capacity is not inferred from byte counters. A plateau without sustained database CPU saturation is not a database-full-load result. Startup/discovery/reset/postflight and warmup are excluded from throughput; all in-flight completion and validation is included.

Resource observation schema 2 additionally retains bounded Linux host CPU ticks (busy, idle, iowait and steal, without double-counted guest ticks), CPU/IO/memory pressure, the sampler's allowed CPU list and runtime parallelism, Docker cumulative throttling counters, fixed sampled Store queue/execution gauges, and projected Search write-pool/indexing-pressure/GC statistics. Host/device evidence includes other runner work; sampler affinity is not a promise that all child processes have that affinity. Missing or unsupported fields remain explicitly unavailable. Pure Search stages retain before/after effective index settings and owned-index indexing/refresh/merge/flush/translog statistics, with explicit 1s refresh and request durability. Lucene flush statistics are not counts or timings of per-request translog fsync. No added metric alone establishes database or storage capacity.
