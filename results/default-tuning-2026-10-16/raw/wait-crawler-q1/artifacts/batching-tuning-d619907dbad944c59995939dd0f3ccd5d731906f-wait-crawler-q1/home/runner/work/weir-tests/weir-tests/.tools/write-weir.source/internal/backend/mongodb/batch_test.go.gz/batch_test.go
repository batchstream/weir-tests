package mongodb

import (
	"bytes"
	"context"
	"fmt"
	"testing"

	pb "github.com/batchstream/weir-protocol/api/weir/v1"
	"github.com/batchstream/weir/internal/execution"
	"go.mongodb.org/mongo-driver/v2/bson"
	"go.mongodb.org/mongo-driver/v2/event"
	"go.mongodb.org/mongo-driver/v2/mongo"
	"go.mongodb.org/mongo-driver/v2/mongo/options"
	"go.mongodb.org/mongo-driver/v2/x/mongo/driver/drivertest"
)

type batchOperationOptions struct {
	resource, action string
	index            uint64
	document         bson.D
	program          string
}

func batchOperation(t testing.TB, opts batchOperationOptions) *pb.ExecuteRequest {
	t.Helper()
	opCommand := &pb.Command{}
	op := &pb.ExecuteRequest{Index: max(1, opts.index), Command: opCommand}
	if opts.action == "read" {
		read := &pb.ReadRequest{Resource: opts.resource}
		recordOperation1 := &pb.Command_Read{Read: read}
		op.Command.Operation = recordOperation1
		return op
	}
	request := &pb.MutateRequest{Resource: opts.resource}
	if opts.action == "program" {
		program := &pb.LuaTransform{Source: []byte(opts.program)}
		form := &pb.Transform_Lua{Lua: program}
		transform := &pb.Transform{Form: form}
		request.Action = &pb.MutateRequest_AtomicTransform{AtomicTransform: transform}
	} else if opts.action == "delete" {
		empty := &pb.Empty{}
		request.Action = &pb.MutateRequest_Delete{Delete: empty}
	} else {
		raw := expressionBSON(t, opts.document)
		document := &pb.Document{ContentType: "application/bson", Data: raw}
		switch opts.action {
		case "create":
			request.Action = &pb.MutateRequest_Create{Create: document}
		case "put":
			request.Action = &pb.MutateRequest_Put{Put: document}
		case "replace":
			request.Action = &pb.MutateRequest_Replace{Replace: document}
		case "expression":
			document.ContentType = ExpressionContentType
			form := &pb.Transform_BackendExpression{BackendExpression: document}
			transform := &pb.Transform{Form: form}
			request.Action = &pb.MutateRequest_AtomicTransform{AtomicTransform: transform}
		default:
			t.Fatal("invalid test action", opts.action)
		}
	}
	recordOperation2 := &pb.Command_Mutate{Mutate: request}
	op.Command.Operation = recordOperation2
	return op
}

func batchMockAdapter(t *testing.T, responses []bson.D, monitor *event.CommandMonitor) *Adapter {
	t.Helper()
	deployment := drivertest.NewMockDeployment(responses...)
	opts := options.Client().SetRetryReads(false).SetRetryWrites(false).SetMaxAdaptiveRetries(0).SetMonitor(monitor)
	opts.Deployment = deployment
	client, err := mongo.Connect(opts)
	if err != nil {
		t.Fatal(err)
	}
	config := Config{Store: "mongo"}
	a := &Adapter{client: client, deployment: deployment, commandMonitor: monitor, config: config}
	t.Cleanup(func() {
		if err := a.Close(); err != nil {
			t.Error(err)
		}
	})
	return a
}

func readCursorResponse(cursor bson.D) bson.D {
	response := bson.D{{Key: "ok", Value: 1}, {Key: "cursor", Value: cursor}}
	return response
}

func TestMongoPointReadRejectsMalformedCursorEvidence(t *testing.T) {
	document := bson.D{{Key: "_id", Value: "a"}, {Key: "n", Value: 1}}
	unexpected := bson.D{{Key: "_id", Value: "unrequested"}}
	cases := []struct {
		name   string
		cursor bson.D
	}{
		{name: "missing id", cursor: bson.D{{Key: "ns", Value: "db.records"}, {Key: "firstBatch", Value: bson.A{}}}},
		{name: "missing namespace", cursor: bson.D{{Key: "id", Value: int64(0)}, {Key: "firstBatch", Value: bson.A{}}}},
		{name: "missing batch", cursor: bson.D{{Key: "id", Value: int64(0)}, {Key: "ns", Value: "db.records"}}},
		{name: "unexpected id", cursor: bson.D{{Key: "id", Value: int64(0)}, {Key: "ns", Value: "db.records"}, {Key: "firstBatch", Value: bson.A{unexpected}}}},
		{name: "duplicate id", cursor: bson.D{{Key: "id", Value: int64(0)}, {Key: "ns", Value: "db.records"}, {Key: "firstBatch", Value: bson.A{document, document}}}},
		{name: "partial", cursor: bson.D{{Key: "id", Value: int64(0)}, {Key: "ns", Value: "db.records"}, {Key: "firstBatch", Value: bson.A{document}}, {Key: "partialResultsReturned", Value: true}}},
		{name: "empty live cursor", cursor: bson.D{{Key: "id", Value: int64(8)}, {Key: "ns", Value: "db.records"}, {Key: "firstBatch", Value: bson.A{}}}},
	}
	for _, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			response := readCursorResponse(tc.cursor)
			cleanup := bson.D{{Key: "ok", Value: 1}, {Key: "cursorsKilled", Value: bson.A{int64(8)}}, {Key: "cursorsAlive", Value: bson.A{}}, {Key: "cursorsNotFound", Value: bson.A{}}, {Key: "cursorsUnknown", Value: bson.A{}}}
			responses := []bson.D{collectionQualificationResponse("db", "records"), response, cleanup}
			a := batchMockAdapter(t, responses, nil)
			var plans []*execution.Plan
			for _, name := range []string{"a", "b"} {
				opts := batchOperationOptions{resource: "db/records/s:" + name, action: "read"}
				p, failure := prepareTestRecord(a, batchOperation(t, opts))
				if failure != nil {
					t.Fatal(failure)
				}
				plans = append(plans, p)
			}
			replies := a.executeRecords(context.Background(), plans)
			for _, reply := range replies {
				if reply.GetReadResult().GetFailure().GetCode() != pb.FailureCode_UNAVAILABLE {
					t.Fatal("malformed response justified a read or missing record", reply)
				}
			}
		})
	}
}

func TestMongoPointReadMatchesTypedIDsAcrossPages(t *testing.T) {
	objectID := bson.NewObjectID()
	integerDoc := bson.D{{Key: "_id", Value: int32(42)}}
	objectDoc := bson.D{{Key: "_id", Value: objectID}}
	stringDoc := bson.D{{Key: "_id", Value: "a"}}
	first := bson.D{{Key: "id", Value: int64(17)}, {Key: "ns", Value: "db.records"}, {Key: "firstBatch", Value: bson.A{integerDoc}}}
	next := bson.D{{Key: "id", Value: int64(0)}, {Key: "ns", Value: "db.records"}, {Key: "nextBatch", Value: bson.A{objectDoc, stringDoc}}}
	responses := []bson.D{collectionQualificationResponse("db", "records"), readCursorResponse(first), readCursorResponse(next)}
	var commands []string
	monitor := &event.CommandMonitor{Started: func(_ context.Context, e *event.CommandStartedEvent) { commands = append(commands, e.CommandName) }}
	a := batchMockAdapter(t, responses, monitor)
	var plans []*execution.Plan
	for i, name := range []string{"s:a", "oid:" + objectID.Hex(), "i:42", "s:missing"} {
		opts := batchOperationOptions{resource: "db/records/" + name, action: "read", index: uint64(i + 9)}
		p, failure := prepareTestRecord(a, batchOperation(t, opts))
		if failure != nil {
			t.Fatal(failure)
		}
		plans = append(plans, p)
	}
	replies := a.executeRecords(context.Background(), plans)
	for i, reply := range replies {
		if i < 3 && reply.GetReadResult().GetDocument() == nil || i == 3 && reply.GetReadResult().GetMissing() == nil {
			t.Fatal("result identity/order mismatch", replies)
		}
	}
	if len(commands) != 3 || commands[0] != "listCollections" || commands[1] != "find" || commands[2] != "getMore" {
		t.Fatal("read batch was not a single cursor", commands)
	}
}

func TestMongoBulkItemEvidence(t *testing.T) {
	matched := bson.D{{Key: "ok", Value: 1}, {Key: "n", Value: 1}, {Key: "nModified", Value: 0}}
	missing := bson.D{{Key: "ok", Value: 1}, {Key: "n", Value: 0}, {Key: "nModified", Value: 0}}
	rejected := bson.D{{Key: "ok", Value: 0}, {Key: "code", Value: 11000}}
	uncertain := bson.D{{Key: "ok", Value: 0}, {Key: "code", Value: 391}}
	cases := []struct {
		name, action string
		doc          bson.D
		concern      bool
		outcome      pb.MutationOutcome
	}{
		{name: "replace noop", action: "replace", doc: matched, outcome: pb.MutationOutcome_APPLIED},
		{name: "replace missing", action: "replace", doc: missing, outcome: pb.MutationOutcome_NOT_APPLIED},
		{name: "expression missing", action: "expression", doc: missing, outcome: pb.MutationOutcome_NOT_APPLIED},
		{name: "duplicate no count", action: "create", doc: rejected, outcome: pb.MutationOutcome_NOT_APPLIED},
		{name: "reauth uncertain", action: "expression", doc: uncertain, outcome: pb.MutationOutcome_UNKNOWN},
		{name: "write concern", action: "replace", doc: matched, concern: true, outcome: pb.MutationOutcome_UNKNOWN},
		{name: "missing count", action: "replace", doc: bson.D{{Key: "ok", Value: 1}, {Key: "nModified", Value: 0}}, outcome: pb.MutationOutcome_UNKNOWN},
		{name: "missing modified count", action: "expression", doc: bson.D{{Key: "ok", Value: 1}, {Key: "n", Value: 1}}, outcome: pb.MutationOutcome_UNKNOWN},
		{name: "error with modification", action: "expression", doc: bson.D{{Key: "ok", Value: 0}, {Key: "code", Value: 112}, {Key: "n", Value: 0}, {Key: "nModified", Value: 1}}, outcome: pb.MutationOutcome_UNKNOWN},
		{name: "error with upsert", action: "put", doc: bson.D{{Key: "ok", Value: 0}, {Key: "code", Value: 11000}, {Key: "upserted", Value: bson.D{{Key: "_id", Value: "a"}}}}, outcome: pb.MutationOutcome_UNKNOWN},
	}
	for _, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			fields, err := scanFields(expressionBSON(t, tc.doc))
			if err != nil {
				t.Fatal(err)
			}
			native := &plan{action: tc.action}
			result := bulkItemReply(native, fields, tc.concern)
			if result.Outcome != tc.outcome {
				t.Fatal(result)
			}
		})
	}
}

func TestMongoBulkCursorRequiresConsistentSummary(t *testing.T) {
	native := &plan{action: "create"}
	work := &execution.Plan{Backend: native}
	item := bson.D{{Key: "ok", Value: 1}, {Key: "idx", Value: 0}, {Key: "n", Value: 1}}
	cursor := bson.D{{Key: "id", Value: int64(0)}, {Key: "ns", Value: "admin.$cmd.bulkWrite"}, {Key: "firstBatch", Value: bson.A{item}}}
	response := bson.D{{Key: "ok", Value: 1}, {Key: "cursor", Value: cursor}, {Key: "nErrors", Value: 0}, {Key: "nInserted", Value: 0}, {Key: "nDeleted", Value: 0}, {Key: "nMatched", Value: 0}, {Key: "nModified", Value: 0}, {Key: "nUpserted", Value: 0}}
	state := &writeBatch{plans: []*execution.Plan{work}, results: make([]*pb.MutationResult, 1)}
	state.cursor.items = 1
	if state.reply(expressionBSON(t, response), true) {
		t.Fatal("contradictory inserted count accepted")
	}
}

func TestMongoBulkReplyQualifiesReplicaSetMetadata(t *testing.T) {
	native := &plan{action: "create"}
	work := &execution.Plan{Backend: native}
	item := bson.D{{Key: "ok", Value: 1}, {Key: "idx", Value: 0}, {Key: "n", Value: 1}}
	cursor := bson.D{{Key: "id", Value: int64(0)}, {Key: "ns", Value: "admin.$cmd.bulkWrite"}, {Key: "firstBatch", Value: bson.A{item}}}
	base := bson.D{{Key: "ok", Value: 1}, {Key: "cursor", Value: cursor}, {Key: "nErrors", Value: 0}, {Key: "nInserted", Value: 1}, {Key: "nDeleted", Value: 0}, {Key: "nMatched", Value: 0}, {Key: "nModified", Value: 0}, {Key: "nUpserted", Value: 0}}
	opTime := bson.D{{Key: "ts", Value: bson.Timestamp{T: 1, I: 2}}, {Key: "t", Value: int64(1)}}
	valid := bson.D{{Key: "electionId", Value: bson.NewObjectID()}, {Key: "opTime", Value: opTime}}
	cases := []struct {
		name   string
		fields bson.D
		valid  bool
	}{
		{name: "replica metadata", fields: valid, valid: true},
		{name: "unknown metadata", fields: bson.D{{Key: "unrecognized", Value: 1}}},
		{name: "bad election id", fields: bson.D{{Key: "electionId", Value: "wrong type"}}},
		{name: "bad opTime", fields: bson.D{{Key: "opTime", Value: 1}}},
		{name: "opTime missing term", fields: bson.D{{Key: "opTime", Value: bson.D{{Key: "ts", Value: bson.Timestamp{T: 1}}}}}},
	}
	for _, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			state := &writeBatch{plans: []*execution.Plan{work}, results: make([]*pb.MutationResult, 1)}
			state.cursor.items = 1
			response := append(append(bson.D(nil), base...), tc.fields...)
			if state.reply(expressionBSON(t, response), true) != tc.valid {
				t.Fatal("unexpected metadata qualification", response)
			}
		})
	}
}

func TestMongoVerboseWriteCursorKeepsItemIndexesAndSessionAcrossPages(t *testing.T) {
	firstItem := bson.D{{Key: "ok", Value: 1}, {Key: "idx", Value: 1}, {Key: "n", Value: 1}}
	nextItem := bson.D{{Key: "ok", Value: 1}, {Key: "idx", Value: 0}, {Key: "n", Value: 1}}
	firstCursor := bson.D{{Key: "id", Value: int64(91)}, {Key: "ns", Value: "admin.$cmd.bulkWrite"}, {Key: "firstBatch", Value: bson.A{firstItem}}}
	nextCursor := bson.D{{Key: "id", Value: int64(0)}, {Key: "ns", Value: "admin.$cmd.bulkWrite"}, {Key: "nextBatch", Value: bson.A{nextItem}}}
	first := bson.D{{Key: "ok", Value: 1}, {Key: "cursor", Value: firstCursor}, {Key: "nErrors", Value: 0}, {Key: "nInserted", Value: 2}, {Key: "nDeleted", Value: 0}, {Key: "nMatched", Value: 0}, {Key: "nModified", Value: 0}, {Key: "nUpserted", Value: 0}}
	next := readCursorResponse(nextCursor)
	responses := []bson.D{collectionQualificationResponse("db", "records"), first, next}
	var commands []string
	var sessions []bson.Raw
	monitor := &event.CommandMonitor{Started: func(_ context.Context, e *event.CommandStartedEvent) {
		if e.CommandName != "bulkWrite" && e.CommandName != "getMore" {
			return
		}
		commands = append(commands, e.CommandName)
		sessions = append(sessions, append(bson.Raw(nil), e.Command.Lookup("lsid").Document()...))
		if e.CommandName == "bulkWrite" && e.Command.Lookup("errorsOnly").Boolean() {
			t.Error("verbose results were not requested")
		}
	}}
	a := batchMockAdapter(t, responses, monitor)
	var plans []*execution.Plan
	for i, id := range []string{"a", "b"} {
		document := bson.D{{Key: "_id", Value: id}}
		opts := batchOperationOptions{resource: "db/records/s:" + id, action: "create", index: uint64(i + 8), document: document}
		p, failure := prepareTestRecord(a, batchOperation(t, opts))
		if failure != nil {
			t.Fatal(failure)
		}
		plans = append(plans, p)
	}
	replies := a.executeRecords(context.Background(), plans)
	for _, reply := range replies {
		if reply.GetMutationResult().GetOutcome() != pb.MutationOutcome_APPLIED {
			t.Fatal("verbose results lost item correspondence", replies)
		}
	}
	if len(commands) != 2 || commands[0] != "bulkWrite" || commands[1] != "getMore" || !bytes.Equal(sessions[0], sessions[1]) {
		t.Fatal("cursor was restarted or changed session", commands)
	}
}

func TestMongoReadContinuationStopsWhenItsCallersCancel(t *testing.T) {
	caller, cancel := context.WithCancel(context.Background())
	defer cancel()
	document := bson.D{{Key: "_id", Value: "a"}}
	cursor := bson.D{{Key: "id", Value: int64(19)}, {Key: "ns", Value: "db.records"}, {Key: "firstBatch", Value: bson.A{document}}}
	cleanup := bson.D{{Key: "ok", Value: 1}, {Key: "cursorsKilled", Value: bson.A{int64(19)}}, {Key: "cursorsAlive", Value: bson.A{}}, {Key: "cursorsNotFound", Value: bson.A{}}, {Key: "cursorsUnknown", Value: bson.A{}}}
	responses := []bson.D{collectionQualificationResponse("db", "records"), readCursorResponse(cursor), cleanup}
	var commands []string
	monitor := &event.CommandMonitor{Succeeded: func(_ context.Context, e *event.CommandSucceededEvent) {
		commands = append(commands, e.CommandName)
		if e.CommandName == "find" {
			cancel()
		}
	}}
	a := batchMockAdapter(t, responses, monitor)
	var plans []*execution.Plan
	for _, id := range []string{"a", "b"} {
		opts := batchOperationOptions{resource: "db/records/s:" + id, action: "read"}
		p, failure := prepareTestRecord(a, batchOperation(t, opts))
		if failure != nil {
			t.Fatal(failure)
		}
		p.Context = caller
		plans = append(plans, p)
	}
	replies := a.executeRecords(context.Background(), plans)
	if replies[0].GetReadResult().GetDocument() == nil || replies[1].GetReadResult().GetFailure().GetCode() != pb.FailureCode_CANCELLED {
		t.Fatal("canceled reads consumed further cursor work", replies)
	}
	if len(commands) != 3 || commands[0] != "listCollections" || commands[1] != "find" || commands[2] != "killCursors" {
		t.Fatal("canceled cursor was continued", commands)
	}
}

func TestMongoCanceledProgramBatchDoesNotStartWrites(t *testing.T) {
	caller, cancel := context.WithCancel(context.Background())
	cancel()
	native := &plan{action: "program"}
	opCommand := &pb.Command{}
	op := &pb.ExecuteRequest{Index: 1, Command: opCommand}
	p := &execution.Plan{ID: op.Index, Command: op.Command, Backend: native, Context: caller}
	a := &Adapter{}
	replies := a.executeRecords(context.Background(), []*execution.Plan{p})
	if replies[0].GetMutationResult().Outcome != pb.MutationOutcome_NOT_STARTED {
		t.Fatal("canceled program started writing", replies)
	}
}

func TestMongoBulkCursorRejectsDuplicateAndMissingIndexes(t *testing.T) {
	first := bson.D{{Key: "ok", Value: 1}, {Key: "idx", Value: 0}, {Key: "n", Value: 1}}
	duplicate := first
	missing := bson.D{{Key: "ok", Value: 1}, {Key: "n", Value: 1}}
	for _, bad := range []bson.D{duplicate, missing} {
		native := &plan{action: "create"}
		work := &execution.Plan{Backend: native}
		state := &writeBatch{plans: []*execution.Plan{work, work}, results: make([]*pb.MutationResult, 2)}
		state.cursor.items = 2
		cursor := bson.D{{Key: "id", Value: int64(0)}, {Key: "ns", Value: "admin.$cmd.bulkWrite"}, {Key: "firstBatch", Value: bson.A{first, bad}}}
		response := bson.D{{Key: "ok", Value: 1}, {Key: "cursor", Value: cursor}, {Key: "nErrors", Value: 0}, {Key: "nInserted", Value: 2}, {Key: "nDeleted", Value: 0}, {Key: "nMatched", Value: 0}, {Key: "nModified", Value: 0}, {Key: "nUpserted", Value: 0}}
		if state.reply(expressionBSON(t, response), true) {
			t.Fatal("invalid index correspondence was accepted")
		}
	}
}

func TestMongoBatchInputEstimateDoesNotRejectLegalRequest(t *testing.T) {
	document := bson.D{{Key: "_id", Value: "a"}}
	cursor := bson.D{{Key: "id", Value: int64(0)}, {Key: "ns", Value: "db.records"}, {Key: "firstBatch", Value: bson.A{document}}}
	responses := []bson.D{collectionQualificationResponse("db", "records"), readCursorResponse(cursor)}
	adapter := batchMockAdapter(t, responses, nil)
	opts := batchOperationOptions{resource: "db/records/s:a", action: "read"}
	work, failure := prepareTestRecord(adapter, batchOperation(t, opts))
	if failure != nil {
		t.Fatal(failure)
	}
	work.Bytes = execution.BackendBatchBytes + 1
	plans := []*execution.Plan{work}
	results := adapter.executeRecords(t.Context(), plans)
	if len(results) != 1 || results[0].GetReadResult().GetDocument() == nil {
		t.Fatal("legal input rejected by a memory estimate", results)
	}
}

func TestMongoReadAggregationAccepts513DistinctDocuments(t *testing.T) {
	const count = 513
	documents := make(bson.A, count)
	plans := make([]*execution.Plan, count)
	for i := range documents {
		documents[i] = bson.D{{Key: "_id", Value: fmt.Sprintf("item-%d", i)}, {Key: "n", Value: i}}
	}
	cursor := bson.D{{Key: "id", Value: int64(0)}, {Key: "ns", Value: "db.records"}, {Key: "firstBatch", Value: documents}}
	responses := []bson.D{collectionQualificationResponse("db", "records"), readCursorResponse(cursor)}
	finds := 0
	monitor := &event.CommandMonitor{Started: func(_ context.Context, e *event.CommandStartedEvent) {
		if e.CommandName == "find" {
			finds++
		}
	}}
	adapter := batchMockAdapter(t, responses, monitor)
	for i := range plans {
		opts := batchOperationOptions{resource: fmt.Sprintf("db/records/s:item-%d", i), action: "read", index: uint64(i + 1)}
		var failure *pb.Failure
		plans[i], failure = prepareTestRecord(adapter, batchOperation(t, opts))
		if failure != nil {
			t.Fatal(failure)
		}
	}
	replies := adapter.executeRecords(t.Context(), plans)
	for i, reply := range replies {
		if reply.GetReadResult().GetDocument() == nil {
			t.Fatalf("record %d failed: %v", i, reply)
		}
	}
	if finds != 1 {
		t.Fatal("batch split by an arbitrary item limit", finds)
	}
}

func TestMongoDuplicateReadSeparatesResultReservations(t *testing.T) {
	for _, mode := range []string{"first smaller estimate", "both retained", "first canceled"} {
		t.Run(mode, func(t *testing.T) {
			document := bson.D{{Key: "_id", Value: "same"}, {Key: "value", Value: 123}}
			cursor := bson.D{{Key: "id", Value: int64(0)}, {Key: "ns", Value: "db.records"}, {Key: "firstBatch", Value: bson.A{document}}}
			responses := []bson.D{collectionQualificationResponse("db", "records"), readCursorResponse(cursor)}
			adapter := batchMockAdapter(t, responses, nil)
			var plans []*execution.Plan
			firstContext, cancelFirst := context.WithCancel(t.Context())
			defer cancelFirst()
			for i := range 2 {
				opts := batchOperationOptions{resource: "db/records/s:same", action: "read", index: 1}
				work, failure := prepareTestRecord(adapter, batchOperation(t, opts))
				if failure != nil {
					t.Fatal(failure)
				}
				if i == 0 {
					work.Context = firstContext
					if mode == "first smaller estimate" {
						work.ResultBytes = 1
					}
				}
				plans = append(plans, work)
			}
			if mode == "first canceled" {
				cancelFirst()
			}
			replies := adapter.executeRecords(t.Context(), plans)
			raw := expressionBSON(t, document)
			if len(replies) != 2 || !bytes.Equal(replies[1].GetReadResult().GetDocument().GetData(), raw) {
				t.Fatal("first RPC budget/cancellation poisoned same-ID peer", replies)
			}
			if mode != "first canceled" {
				if replies[0].GetReadResult().GetDocument() != replies[1].GetReadResult().GetDocument() {
					t.Fatal("immutable data was not shared with independent reservations", replies)
				}
			} else {
				code := pb.FailureCode_CANCELLED
				if replies[0].GetReadResult().GetFailure().GetCode() != code {
					t.Fatal("failed first RPC retained another caller's bytes", replies)
				}
			}
		})
	}
}
