# Database saturation comparison

Backend **search**. Started 2026-10-15T18:01:42.52156421Z.

independent OS client processes send one record per native call or streaming SDK RPC; native FindOne/ReplaceOne or single-ID mget/PUT; no client aggregation; worker-owned disjoint IDs; common phase barriers and unchanged pools across warmup and measurement; alternating AB/BA; latency is each business request including validation, queueing and any server aggregation; independent persisted postflight; Search uses explicit refresh_interval=1s, translog.durability=request, one primary and zero replicas; sustained database CPU requires >=5 intervals, >=80% measurement coverage, mean CPU>=threshold and CPU>=threshold during >=80% measurement duration in every round, plus <=10% next-level throughput gain.

Warmup 1m0s and measurement 1m0s per path/stage, 3 paired rounds, requested writes 100%.

Complete business-request budget for both paths: 10s.

4 independent OS client processes. Each worker sends one business request containing one record, waits for its acknowledged result, and validates it. p50/p95/p99 describe individual requests; histograms are pooled rather than averaging process quantiles.

| Batch | Workers | Round | Path | Read | Write | Success | Errors/unknown | Ops/s | p95 call ms | DB CPU budget % | Full CPU time % | Sampling coverage % | Verified |
| ---: | ---: | ---: | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | --- |
| 1 | 128 | 1 | direct | 0 | 125714 | 125714 | 0 | 2093.6 | 98.303 | 49.6 | 3.6 | 99.1 | true |
| 1 | 128 | 1 | weir | 0 | 596843 | 596843 | 0 | 9945.1 | 18.431 | 24.5 | 0.0 | 99.6 | true |
| 1 | 128 | 2 | direct | 0 | 135570 | 135570 | 0 | 2257.6 | 65.535 | 45.1 | 0.0 | 98.9 | true |
| 1 | 128 | 2 | weir | 0 | 520462 | 520462 | 0 | 8670.7 | 22.527 | 23.3 | 0.0 | 98.3 | true |
| 1 | 128 | 3 | direct | 0 | 131986 | 131986 | 0 | 2197.9 | 65.535 | 42.5 | 0.0 | 98.8 | true |
| 1 | 128 | 3 | weir | 0 | 563328 | 563328 | 0 | 9387.9 | 20.479 | 21.8 | 0.0 | 98.3 | true |
| 1 | 512 | 1 | direct | 0 | 131044 | 131044 | 0 | 2176.5 | 294.911 | 44.8 | 0.0 | 98.7 | true |
| 1 | 512 | 1 | weir | 0 | 688014 | 688014 | 0 | 11463.3 | 73.727 | 35.8 | 0.0 | 98.8 | true |
| 1 | 512 | 2 | direct | 0 | 139169 | 139169 | 0 | 2311.9 | 262.143 | 45.8 | 0.0 | 98.6 | true |
| 1 | 512 | 2 | weir | 0 | 711983 | 711983 | 0 | 11859.8 | 65.535 | 33.7 | 0.0 | 98.3 | true |
| 1 | 512 | 3 | direct | 0 | 138978 | 138978 | 0 | 2308.2 | 245.759 | 44.1 | 0.0 | 98.6 | true |
| 1 | 512 | 3 | weir | 0 | 729769 | 729769 | 0 | 12159.3 | 65.535 | 32.4 | 0.0 | 98.4 | true |
| 1 | 1024 | 1 | direct | 0 | 139040 | 139040 | 0 | 2301.0 | 524.287 | 45.9 | 0.0 | 98.6 | true |
| 1 | 1024 | 1 | weir | 0 | 733470 | 733470 | 0 | 12213.2 | 147.455 | 31.6 | 0.0 | 99.8 | true |
| 1 | 1024 | 2 | direct | 0 | 145137 | 145137 | 0 | 2403.1 | 491.519 | 46.4 | 0.0 | 98.5 | true |
| 1 | 1024 | 2 | weir | 0 | 712257 | 712257 | 0 | 11865.3 | 147.455 | 32.3 | 0.0 | 98.4 | true |
| 1 | 1024 | 3 | direct | 0 | 136535 | 136535 | 0 | 2260.5 | 524.287 | 41.9 | 0.0 | 99.7 | true |
| 1 | 1024 | 3 | weir | 0 | 782378 | 782378 | 0 | 13031.2 | 122.879 | 30.9 | 0.0 | 99.6 | true |

Measured Weir adapter and streaming RPC evidence (warmup, reset and postflight excluded):

| Batch | Workers | Round | Adapter invocations | Mean adapter batch | Execute RPCs | Queue mean ms | Adapter mean ms | Rejections |
| ---: | ---: | ---: | ---: | ---: | --- | ---: | ---: | ---: |
| 1 | 128 | 1 | 4663 | 127.995 | 596843 | 3.498 | 3.901 | 0 |
| 1 | 128 | 2 | 4067 | 127.972 | 520462 | 3.772 | 4.803 | 0 |
| 1 | 128 | 3 | 4401 | 128.000 | 563328 | 3.624 | 4.162 | 0 |
| 1 | 512 | 1 | 5399 | 127.434 | 688014 | 7.696 | 16.765 | 0 |
| 1 | 512 | 2 | 5577 | 127.664 | 711983 | 7.499 | 15.729 | 0 |
| 1 | 512 | 3 | 5715 | 127.694 | 729769 | 7.484 | 14.531 | 0 |
| 1 | 1024 | 1 | 5789 | 126.701 | 733470 | 9.625 | 28.962 | 0 |
| 1 | 1024 | 2 | 5628 | 126.556 | 712257 | 10.299 | 28.291 | 0 |
| 1 | 1024 | 3 | 6169 | 126.824 | 782378 | 9.314 | 27.069 | 0 |

**Batch 1: database-full-load throughput comparison unavailable.** both paths must independently demonstrate sustained database CPU saturation and a verified next-level throughput plateau; increase concurrency or isolate client/Weir resources; I/O/network-bound saturation needs additional device/link capacity evidence.

Best verified business QPS within this ladder: direct 2321.5 (1024 workers), Weir 12369.9 (1024 workers), observed change +432.83%. This is a measured business-throughput comparison, not a maximum-database-capacity claim.

Observed single-request business performance at matched client concurrency (independent of the database-capacity qualification):

| Workers | Direct QPS | Weir QPS | Change | Direct p50/p95/p99 ms | Weir p50/p95/p99 ms |
| ---: | ---: | ---: | ---: | --- | --- |
| 128 | 2183.0 | 9334.5 | +327.59% | 57.343 / 73.727 / 131.071 | 14.335 / 20.479 / 24.575 |
| 512 | 2265.6 | 11827.5 | +422.06% | 229.375 / 262.143 / 589.823 | 45.055 / 65.535 / 81.919 |
| 1024 | 2321.5 | 12369.9 | +432.83% | 458.751 / 524.287 / 720.895 | 81.919 / 131.071 / 163.839 |

These QPS and latency observations apply to this hardware and measured concurrency range. A business-throughput improvement can exist without demonstrating the maximum database capacity. An underfull database or missing next-level plateau keeps the database-capacity comparison unavailable.

Aggregation evidence: the JSON records one business request per record, Execute RPC counts, adapter invocation counts, average adapter batch and its cumulative histogram, and RPCs per adapter invocation. An adapter invocation is not necessarily one physical database wire command. MongoDB physical find/update/bulkWrite/getMore/killCursors/commitTransaction/abortTransaction deltas come from owned serverStatus at timed boundaries; missing counters remain unavailable. Elasticsearch has no equivalent physical HTTP-command counter. Every child PID, configured native pool limit, final revision ranges, exit result and sampled CPU/RSS is retained; coordinator sampling CPU is excluded from business-client CPU.

The JSON retains before/after raw public Weir metrics and their observed deltas, every resource sample, monitor failures, raw cumulative database/container I/O and network counters, CPU quota/host core denominator, and client/Weir cumulative CPU. Docker CPU uses cumulative Engine usage and read timestamps across each entire sampling interval, never CLI instantaneous percentages. Both interval endpoints must succeed; missing intervals reduce full-run coverage. Samples include monitoring traffic and background database work. Native ps CPU has platform-dependent clock resolution. Native databases share the host CPU budget with the client and Weir. Disk/network utilization or capacity is not inferred from byte counters. A plateau without sustained database CPU saturation is not a database-full-load result. Startup/discovery/reset/postflight and warmup are excluded from throughput; all in-flight completion and validation is included.

Resource observation schema 2 additionally retains bounded Linux host CPU ticks (busy, idle, iowait and steal, without double-counted guest ticks), CPU/IO/memory pressure, the sampler's allowed CPU list and runtime parallelism, Docker cumulative throttling counters, fixed sampled Store queue/execution gauges, and projected Search write-pool/indexing-pressure/GC statistics. Host/device evidence includes other runner work; sampler affinity is not a promise that all child processes have that affinity. Missing or unsupported fields remain explicitly unavailable. Pure Search stages retain before/after effective index settings and owned-index indexing/refresh/merge/flush/translog statistics, with explicit 1s refresh and request durability. Lucene flush statistics are not counts or timings of per-request translog fsync. No added metric alone establishes database or storage capacity.
