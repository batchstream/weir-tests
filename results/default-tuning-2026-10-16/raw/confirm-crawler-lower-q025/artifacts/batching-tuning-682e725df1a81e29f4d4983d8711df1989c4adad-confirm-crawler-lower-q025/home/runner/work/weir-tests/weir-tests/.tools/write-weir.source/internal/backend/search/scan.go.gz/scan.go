package search

import (
	"bytes"
	"context"
	"encoding/json"
	"math"
	"net/http"
	"net/url"
	"strconv"

	"github.com/batchstream/weir-protocol/api/protocol"
	pb "github.com/batchstream/weir-protocol/api/weir/v1"
	"github.com/batchstream/weir/internal/execution"
	"google.golang.org/protobuf/proto"
)

const scanWorkingBytes = 64 << 20

type scanPlan struct {
	execution.ScanProgress
	index                    string
	query                    json.RawMessage
	projection               *pb.Projection
	items                    int
	batchSize                int
	pit                      string
	after                    int64
	hasAfter, opened, closed bool
	pageSize                 uint64
	fingerprint              string
	resumed, transferred     bool
}

type scanCheckpoint struct {
	PIT   string `json:"pit"`
	Index string `json:"index"`
	After int64  `json:"after"`
}

// The profile fixes the PIT checkpoint and dialect-specific ordering semantics.
// Native batch capacity is learned within each page, never part of a token.
func (a *Adapter) scanProfile() string {
	return "search:" + a.dialect + ":v2"
}

func (a *Adapter) prepareScan(ctx context.Context, req *pb.ScanRequest) (*execution.Plan, *pb.Failure) {
	if ctx.Err() != nil {
		return nil, protocol.ContextFailure(ctx)
	}
	if f := protocol.ValidateScan(req); f != nil {
		return nil, f
	}
	parts, _ := protocol.ParseRelativeResource(req.Resource)
	if len(parts) != 1 || !validIndex(parts[0]) {
		return nil, protocol.Fail(pb.FailureCode_INVALID_ARGUMENT, "Scan requires one Search index or single-index alias")
	}
	native := &scanPlan{
		index:       parts[0],
		items:       a.options().Scan.Documents,
		batchSize:   a.options().Scan.Documents,
		query:       json.RawMessage(`{"match_all":{}}`),
		pageSize:    protocol.ScanPageSize(req),
		fingerprint: protocol.ScanFingerprint(req, a.config.Store, a.scanProfile()),
	}
	if d := req.Filter; d != nil {
		if d.ContentType != "application/json" {
			return nil, protocol.Fail(pb.FailureCode_UNSUPPORTED, "Search Scan filter requires JSON")
		}
		if !object(d.Data) || validateJSON(ctx, d.Data) != nil {
			if ctx.Err() != nil {
				return nil, protocol.ContextFailure(ctx)
			}
			return nil, protocol.Fail(pb.FailureCode_INVALID_ARGUMENT, "invalid JSON filter")
		}
		native.query = d.Data
	}
	native.projection = req.Projection
	if len(req.ContinuationToken) != 0 {
		raw, err := protocol.DecodeScanToken(req.ContinuationToken, a.scanProfile(), native.fingerprint)
		if err != nil {
			return nil, protocol.Fail(pb.FailureCode_INVALID_ARGUMENT, "invalid or mismatched Search Scan continuation")
		}
		var checkpoint scanCheckpoint
		decodeErr := json.Unmarshal(raw, &checkpoint)
		canonical, _ := json.Marshal(checkpoint)
		if decodeErr != nil || !bytes.Equal(raw, canonical) || checkpoint.PIT == "" || !validIndex(checkpoint.Index) || checkpoint.After < 0 {
			return nil, protocol.Fail(pb.FailureCode_INVALID_ARGUMENT, "invalid or mismatched Search Scan continuation")
		}
		native.pit = checkpoint.PIT
		native.index = checkpoint.Index
		native.after = checkpoint.After
		native.hasAfter = true
		native.opened = true
		native.resumed = true
	}
	p := &execution.Plan{
		Key:          req.Resource,
		Bytes:        proto.Size(req) + execution.EntryOverheadBytes + 4096,
		ResultBytes:  a.options().Scan.ResultBytes(),
		WorkingBytes: scanWorkingBytes,
		Backend:      native,
	}
	if ctx.Err() != nil {
		return nil, protocol.ContextFailure(ctx)
	}
	return p, nil
}

func (a *Adapter) fetchScan(ctx context.Context, p *execution.Plan) *execution.ScanPage {
	n := p.Backend.(*scanPlan)
	pitKeepAlive := strconv.FormatInt(a.options().PITKeepAlive.Milliseconds(), 10) + "ms"
	page := &execution.ScanPage{}
	if n.closed || ctx.Err() != nil {
		page.Failure = protocol.ContextFailure(ctx)
		return page
	}
	if !n.opened {
		caps, f := a.inspect(ctx, n.index, false)
		if f != nil {
			page.Failure = f
			return page
		}
		if !caps.source {
			page.Failure = protocol.Fail(pb.FailureCode_UNSUPPORTED, "Scan requires stored full source")
			return page
		}
		n.index = caps.index
		call := exchange{
			path: "/" + url.PathEscape(n.index) + "/_pit?keep_alive=" + pitKeepAlive + "&allow_partial_search_results=false",
			body: []byte("{}")}
		if a.dialect == OpenSearchProduct {
			call.path = "/" + url.PathEscape(n.index) + "/_search/point_in_time?keep_alive=" + pitKeepAlive + "&allow_partial_pit_creation=false"
		}
		n.opened = true
		status, raw, err := a.request(ctx, call)
		f = a.scanExchangeFailure(ctx, status, raw, err)
		if f != nil {
			page.Failure = f
			return page
		}
		page.Failure = a.openPITReply(raw, n)
		if page.Failure != nil {
			return page
		}
	}
	if n.pit == "" {
		page.Failure = protocol.Fail(pb.FailureCode_INTERNAL, "PIT unavailable")
		return page
	}
	if n.Count >= n.pageSize {
		page.Failure = protocol.Fail(pb.FailureCode_INTERNAL, "Scan fetched beyond its logical page")
		return page
	}
	remaining := n.pageSize - n.Count
	n.items = int(min(uint64(n.batchSize), uint64(a.options().Scan.Documents), remaining))
	pit := map[string]any{"id": n.pit, "keep_alive": pitKeepAlive}
	body := map[string]any{
		"pit":              pit,
		"query":            n.query,
		"size":             n.items,
		"sort":             []string{"_shard_doc"},
		"track_total_hits": false,
		"_source":          true,
	}
	if n.projection != nil {
		key := "excludes"
		if n.projection.Mode == pb.ProjectionMode_INCLUDE {
			key = "includes"
		}
		source := map[string][]string{key: n.projection.Fields}
		body["_source"] = source
	}
	if n.hasAfter {
		body["search_after"] = []int64{n.after}
	}
	encoded, _ := json.Marshal(body)
	call := exchange{path: "/_search?allow_partial_search_results=false", body: encoded, operation: "search"}
	status, raw, err := a.request(ctx, call)
	failure := a.scanExchangeFailure(ctx, status, raw, err)
	if failure != nil {
		page.Failure = failure
		return page
	}
	page = a.scanReply(ctx, raw, n)
	if page.Failure != nil {
		return page
	}
	if !page.Exhausted && n.Count+uint64(len(page.Documents)) >= n.pageSize {
		checkpoint := scanCheckpoint{PIT: n.pit, Index: n.index, After: n.after}
		state, _ := json.Marshal(checkpoint)
		token, err := protocol.EncodeScanToken(a.scanProfile(), n.fingerprint, state)
		if err != nil {
			page.Documents = nil
			page.Failure = protocol.Fail(pb.FailureCode_INTERNAL, "Scan continuation encoding failed")
			return page
		}
		page.Complete = true
		page.NextContinuationToken = token
	}
	return page
}
func (a *Adapter) scanExchangeFailure(ctx context.Context, status int, raw []byte, err error) *pb.Failure {
	if ctx.Err() != nil {
		return protocol.ContextFailure(ctx)
	}
	if err == errTimeout {
		return protocol.Fail(pb.FailureCode_DEADLINE_EXCEEDED, "Scan backend call timed out")
	}
	if err == errTransport || status == 429 || status == 503 {
		return protocol.Fail(pb.FailureCode_UNAVAILABLE, "Scan backend unavailable")
	}
	if err != nil {
		return protocol.Fail(pb.FailureCode_INTERNAL, "invalid, truncated or excessive Scan response")
	}
	if status != 200 {
		return a.nativeResponseFailure(ctx, status, raw)
	}
	return nil
}

func (a *Adapter) openPITReply(raw []byte, n *scanPlan) *pb.Failure {
	var fields map[string]json.RawMessage
	if json.Unmarshal(raw, &fields) != nil {
		return protocol.Fail(pb.FailureCode_INTERNAL, "invalid PIT response")
	}
	key := "id"
	if a.dialect == OpenSearchProduct {
		key = "pit_id"
	}
	var id string
	if json.Unmarshal(fields[key], &id) != nil || len(id) == 0 {
		return protocol.Fail(pb.FailureCode_INTERNAL, "missing or excessive PIT ID")
	}
	n.pit = id // Keep latest known state for cleanup even on a failed envelope.
	for name := range fields {
		if name != key && name != "_shards" && (name != "creation_time" || a.dialect != OpenSearchProduct) {
			return protocol.Fail(pb.FailureCode_INTERNAL, "unexpected PIT envelope field")
		}
	}
	if a.dialect == OpenSearchProduct {
		var created int64
		if json.Unmarshal(fields["creation_time"], &created) != nil || created <= 0 {
			return protocol.Fail(pb.FailureCode_INTERNAL, "missing PIT creation evidence")
		}
	}
	return scanShards(fields["_shards"])
}

func scanShards(raw []byte) *pb.Failure {
	var shards struct {
		Total, Successful, Skipped, Failed *int
		Failures                           json.RawMessage
	}
	if json.Unmarshal(raw, &shards) != nil || shards.Total == nil || shards.Successful == nil || shards.Skipped == nil || shards.Failed == nil {
		return protocol.Fail(pb.FailureCode_INTERNAL, "missing shard participation evidence")
	}
	if *shards.Failed > 0 {
		return protocol.Fail(pb.FailureCode_UNAVAILABLE, "Scan shard failure")
	}
	// Native successful includes normally skipped shards; do not add skipped a
	// second time, or misclassify a healthy match_none query as partial results.
	if *shards.Total < 1 || *shards.Successful != *shards.Total || *shards.Failed != 0 || *shards.Skipped < 0 || *shards.Skipped > *shards.Successful {
		return protocol.Fail(pb.FailureCode_INTERNAL, "inconsistent shard participation")
	}
	if shards.Failures != nil && string(shards.Failures) != "[]" {
		return protocol.Fail(pb.FailureCode_INTERNAL, "contradictory shard failures")
	}
	return nil
}

func (a *Adapter) scanReply(ctx context.Context, raw []byte, n *scanPlan) *execution.ScanPage {
	page := &execution.ScanPage{Failure: protocol.Fail(pb.FailureCode_INTERNAL, "incomplete or malformed search envelope")}
	if ctx.Err() != nil {
		page.Failure = protocol.ContextFailure(ctx)
		return page
	}
	var fields map[string]json.RawMessage
	if json.Unmarshal(raw, &fields) != nil {
		return page
	}
	if idRaw, exists := fields["pit_id"]; exists {
		var id string
		if json.Unmarshal(idRaw, &id) != nil || id == "" {
			return page
		}
		n.pit = id
	} else if a.dialect == ElasticsearchProduct {
		return page
	}
	for _, key := range []string{"error", "aggregations", "suggest", "_clusters"} {
		if _, exists := fields[key]; exists {
			return page
		}
	}
	var timedOut *bool
	var took *int64
	if json.Unmarshal(fields["timed_out"], &timedOut) != nil ||
		timedOut == nil ||
		json.Unmarshal(fields["took"], &took) != nil ||
		took == nil ||
		*took < 0 {
		return page
	}
	if *timedOut {
		page.Failure = protocol.Fail(pb.FailureCode_DEADLINE_EXCEEDED, "search timed out")
		return page
	}
	if early, exists := fields["terminated_early"]; exists {
		var terminated *bool
		if json.Unmarshal(early, &terminated) != nil || terminated == nil || *terminated {
			return page
		}
	}
	if f := scanShards(fields["_shards"]); f != nil {
		page.Failure = f
		return page
	}
	var hits struct {
		Hits     json.RawMessage
		MaxScore json.RawMessage `json:"max_score"`
	}
	if json.Unmarshal(fields["hits"], &hits) != nil || len(hits.Hits) == 0 || hits.Hits[0] != '[' || !scanScore(hits.MaxScore) {
		return page
	}
	var rows []json.RawMessage
	if json.Unmarshal(hits.Hits, &rows) != nil {
		return page
	}
	if len(rows) > n.items {
		page.Failure = protocol.Fail(pb.FailureCode_INTERNAL, "search returned more hits than requested")
		return page
	}
	docs := make([]*pb.Document, 0, len(rows))
	last := n.after
	hasLast := n.hasAfter
	acceptedLast := last
	acceptedBytes := 0
	retaining := true
	for _, row := range rows {
		if ctx.Err() != nil {
			page.Failure = protocol.ContextFailure(ctx)
			return page
		}
		var hit struct {
			Index  string            `json:"_index"`
			ID     string            `json:"_id"`
			Source json.RawMessage   `json:"_source"`
			Score  json.RawMessage   `json:"_score"`
			Sort   []json.RawMessage `json:"sort"`
		}
		if json.Unmarshal(row, &hit) != nil {
			return page
		}
		if hit.Index != n.index ||
			hit.ID == "" ||
			!object(hit.Source) ||
			validateJSON(ctx, hit.Source) != nil ||
			!scanScore(hit.Score) ||
			len(hit.Sort) != 1 {
			if ctx.Err() != nil {
				page.Failure = protocol.ContextFailure(ctx)
			}
			return page
		}
		position, err := strconv.ParseInt(string(hit.Sort[0]), 10, 64)
		if err != nil || position < 0 || hasLast && position <= last {
			return page
		}
		last, hasLast = position, true
		if retaining && (len(docs) == 0 || acceptedBytes+len(hit.Source) <= a.options().Scan.Bytes) {
			doc := &pb.Document{ContentType: "application/json", Data: hit.Source}
			docs = append(docs, doc)
			acceptedBytes += len(hit.Source)
			acceptedLast = position
		} else {
			// Validate the complete envelope before publishing this ordered prefix.
			// Its tail is refetched from the last accepted position on the same PIT.
			retaining = false
		}
	}
	if len(docs) != 0 {
		n.after, n.hasAfter = acceptedLast, true
	}
	if len(docs) < len(rows) {
		n.batchSize = max(1, len(docs))
	}
	page.Documents = docs
	// Only a complete, validated search envelope on this same PIT and sort can
	// establish exhaustion. total hits is deliberately neither requested nor used.
	page.Exhausted = len(rows) == 0
	page.Failure = nil
	return page
}

func scanScore(raw json.RawMessage) bool {
	if string(raw) == "null" {
		return true
	}
	if len(raw) == 0 || raw[0] != '-' && (raw[0] < '0' || raw[0] > '9') {
		return false
	}
	number, err := strconv.ParseFloat(string(raw), 64)
	return err == nil && !math.IsNaN(number) && !math.IsInf(number, 0)
}

func (a *Adapter) closeScan(ctx context.Context, p *execution.Plan) *pb.Failure {
	n := p.Backend.(*scanPlan)
	if n.closed {
		return nil
	}
	n.closed = true
	defer func() {
		n.pit = ""
		n.query = nil
		n.projection = nil
	}()
	// An input checkpoint remains retryable until the backend's keep-alive
	// expires, including when the last page or its transport acknowledgement is
	// lost. The caller cannot acknowledge receipt through a completed Execute RPC.
	if n.resumed || n.transferred {
		return nil
	}
	if n.pit == "" {
		if n.opened {
			return protocol.Fail(pb.FailureCode_UNAVAILABLE, "PIT allocation reply lost; remote cleanup unconfirmed")
		}
		return nil
	}
	body := map[string]any{"id": n.pit}
	endpoint := "/_pit"
	if a.dialect == OpenSearchProduct {
		body = map[string]any{"pit_id": []string{n.pit}}
		endpoint = "/_search/point_in_time"
	}
	raw, _ := json.Marshal(body)
	call := exchange{path: endpoint, body: raw, method: http.MethodDelete}
	status, raw, err := a.request(ctx, call)
	if err != nil || status != 200 {
		return protocol.Fail(pb.FailureCode_UNAVAILABLE, "remote PIT cleanup unconfirmed")
	}
	if a.dialect == OpenSearchProduct {
		var reply struct {
			PITs []struct {
				ID         string `json:"pit_id"`
				Successful bool
			}
		}
		if json.Unmarshal(raw, &reply) == nil && len(reply.PITs) == 1 && reply.PITs[0].ID == n.pit && reply.PITs[0].Successful {
			return nil
		}
	} else {
		var reply struct {
			Succeeded bool
			Freed     *int `json:"num_freed"`
		}
		if json.Unmarshal(raw, &reply) == nil && reply.Succeeded && reply.Freed != nil && *reply.Freed >= 0 {
			return nil
		}
	}
	return protocol.Fail(pb.FailureCode_UNAVAILABLE, "remote PIT cleanup unconfirmed")
}
