package search

import (
	"context"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"net/http/httptest"
	"strings"
	"sync"
	"sync/atomic"
	"testing"
	"time"

	pb "github.com/batchstream/weir-protocol/api/weir/v1"
	"github.com/batchstream/weir/internal/execution"
)

func TestLuaTransformReevaluatesAfterSearchVersionConflict(t *testing.T) {
	var gets, puts atomic.Int32
	var timestampMu sync.Mutex
	var timestamps []string
	handler := http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if r.URL.Path == "/records" {
			_, _ = io.WriteString(w, `{"records":{"settings":{"index.uuid":"test","index.number_of_shards":"1"},"mappings":{"_source":{"enabled":true}}}}`)
			return
		}
		switch r.URL.Path {
		case "/records/_mget":
			if r.URL.Query().Get("realtime") != "true" {
				t.Errorf("transform read was not realtime: %s", r.URL.RawQuery)
			}
			attempt := gets.Add(1)
			sequence := attempt
			count := 1
			if attempt > 1 {
				count = 10
			}
			_, _ = fmt.Fprintf(w, `{"docs":[{"_index":"records","_id":"item","found":true,"_seq_no":%d,"_primary_term":1,"_source":{"n":%d}}]}`, sequence, count)
		case "/_bulk":
			body, err := io.ReadAll(r.Body)
			if err != nil {
				t.Errorf("read replacement: %v", err)
				return
			}
			attempt := puts.Add(1)
			wantCount, wantSequence := 2, "1"
			if attempt == 2 {
				wantCount, wantSequence = 11, "2"
			}
			lines := strings.Split(strings.TrimSpace(string(body)), "\n")
			var source struct {
				N         int    `json:"n"`
				UpdatedAt string `json:"updated_at"`
			}
			if len(lines) != 2 || json.Unmarshal([]byte(lines[1]), &source) != nil || source.N != wantCount || source.UpdatedAt == "" || !strings.Contains(lines[0], `"if_seq_no":`+wantSequence) || !strings.Contains(lines[0], `"if_primary_term":1`) {
				t.Errorf("conditional replacement %d: body=%s query=%s", attempt, body, r.URL.RawQuery)
			}
			timestampMu.Lock()
			timestamps = append(timestamps, source.UpdatedAt)
			timestampMu.Unlock()
			if attempt == 1 {
				_, _ = io.WriteString(w, `{"errors":true,"took":1,"items":[{"index":{"_index":"records","_id":"item","error":{"type":"version_conflict_engine_exception"},"status":409}}]}`)
				return
			}
			w.WriteHeader(http.StatusOK)
			_, _ = io.WriteString(w, `{"errors":false,"took":1,"items":[{"index":{"_index":"records","_id":"item","status":200,"_version":3,"_seq_no":3,"_primary_term":1,"result":"updated","_shards":{"total":1,"successful":1,"failed":0}}}]}`)
		default:
			http.Error(w, "unexpected method", http.StatusMethodNotAllowed)
		}
	})
	server := httptest.NewServer(handler)
	defer server.Close()
	a := &Adapter{dialect: ElasticsearchProduct,
		config: Config{Store: "search", URL: server.URL},
		client: server.Client(),
		ctx:    context.Background(),
	}
	program := &pb.LuaTransform{
		Source: []byte(`return function(current, incoming) return {n = current.n + incoming.step, updated_at = weir.time.now()} end`),
		Input:  &pb.Document{ContentType: "application/json", Data: []byte(`{"step":1}`)},
	}
	form := &pb.Transform_Lua{Lua: program}
	transform := &pb.Transform{Form: form}
	action := &pb.MutateRequest_AtomicTransform{AtomicTransform: transform}
	mutation := &pb.MutateRequest{Resource: "records/s:item", Action: action}
	operationOperation := &pb.Command_Mutate{Mutate: mutation}
	operationCommand := &pb.Command{Operation: operationOperation}
	operation := &pb.ExecuteRequest{Index: 1, Command: operationCommand}
	work, failure := prepareTestRecord(a, operation)
	if failure != nil {
		t.Fatal(failure)
	}
	results := a.executeRecords(context.Background(), []*execution.Plan{work})
	if len(results) != 1 {
		t.Fatalf("unexpected transform result: %#v", results)
	}
	if result := results[0].GetMutationResult(); result.GetOutcome() != pb.MutationOutcome_APPLIED || result.GetFailure() != nil {
		t.Fatalf("unexpected transform result: outcome=%s failure=%+v gets=%d puts=%d", result.GetOutcome(), result.GetFailure(), gets.Load(), puts.Load())
	}
	if gets.Load() != 2 || puts.Load() != 2 {
		t.Fatalf("conflict did not cause a fresh read and evaluation: gets=%d puts=%d", gets.Load(), puts.Load())
	}
	timestampMu.Lock()
	defer timestampMu.Unlock()
	observedAt := work.Backend.(*plan).program.ObservedAt
	if observedAt.IsZero() || len(timestamps) != 2 || timestamps[0] != timestamps[1] || timestamps[0] != observedAt.UTC().Format(time.RFC3339Nano) {
		t.Fatalf("CAS retry changed operation observation time: %v observed=%v", timestamps, observedAt)
	}
}

func TestLuaTransformRejectsUnqualifiedPipelines(t *testing.T) {
	program := &pb.LuaTransform{Source: []byte("return function(current, incoming) return weir.keep() end")}
	form := &pb.Transform_Lua{Lua: program}
	transform := &pb.Transform{Form: form}
	action := &pb.MutateRequest_AtomicTransform{AtomicTransform: transform}
	mutation := &pb.MutateRequest{Resource: "records/s:item", Action: action}
	operationOperation := &pb.Command_Mutate{Mutate: mutation}
	operationCommand := &pb.Command{Operation: operationOperation}
	operation := &pb.ExecuteRequest{Index: 1, Command: operationCommand}
	for name, pipeline := range map[string]string{"default": "index.default_pipeline", "final": "index.final_pipeline"} {
		t.Run(name, func(t *testing.T) {
			var documentReads atomic.Int32
			handler := http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
				if r.URL.Path == "/records" {
					_, _ = fmt.Fprintf(w, `{"records":{"settings":{"index.uuid":"test","index.number_of_shards":"1",%q:"route"},"mappings":{"_source":{"enabled":true}}}}`, pipeline)
					return
				}
				if r.URL.Path == "/records/_mget" {
					documentReads.Add(1)
				}
				http.NotFound(w, r)
			})
			server := httptest.NewServer(handler)
			defer server.Close()
			a := &Adapter{dialect: ElasticsearchProduct,
				config: Config{Store: "search", URL: server.URL},
				client: server.Client(),
				ctx:    context.Background(),
			}
			work, failure := prepareTestRecord(a, operation)
			if failure != nil {
				t.Fatal(failure)
			}
			results := a.executeRecords(context.Background(), []*execution.Plan{work})
			if len(results) != 1 || results[0].GetMutationResult().GetFailure().GetCode() != pb.FailureCode_UNSUPPORTED {
				t.Fatalf("pipeline was not rejected: %#v", results)
			}
			if documentReads.Load() != 0 {
				t.Fatal("program accessed a document before pipeline qualification")
			}
		})
	}
}
