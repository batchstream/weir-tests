# Database saturation comparison

Backend **mongo**. Started 2026-10-15T18:14:29.115931867Z.

independent OS client processes send one record per native call or streaming SDK RPC; native FindOne/ReplaceOne or single-ID mget/PUT; no client aggregation; worker-owned disjoint IDs; common phase barriers and unchanged pools across warmup and measurement; alternating AB/BA; latency is each business request including validation, queueing and any server aggregation; independent persisted postflight; Search uses explicit refresh_interval=1s, translog.durability=request, one primary and zero replicas; sustained database CPU requires >=5 intervals, >=80% measurement coverage, mean CPU>=threshold and CPU>=threshold during >=80% measurement duration in every round, plus <=10% next-level throughput gain.

Warmup 30s and measurement 30s per path/stage, 3 paired rounds, requested writes 0%.

Complete business-request budget for both paths: 10s.

4 independent OS client processes. Each worker sends one business request containing one record, waits for its acknowledged result, and validates it. p50/p95/p99 describe individual requests; histograms are pooled rather than averaging process quantiles.

| Batch | Workers | Round | Path | Read | Write | Success | Errors/unknown | Ops/s | p95 call ms | DB CPU budget % | Full CPU time % | Sampling coverage % | Verified |
| ---: | ---: | ---: | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | --- |
| 1 | 4 | 1 | direct | 248026 | 0 | 248026 | 0 | 8267.2 | 0.639 | 99.8 | 99.7 | 99.7 | true |
| 1 | 4 | 1 | weir | 109266 | 0 | 109266 | 0 | 3642.0 | 1.791 | 49.5 | 0.0 | 99.3 | true |
| 1 | 4 | 2 | direct | 247897 | 0 | 247897 | 0 | 8262.9 | 0.639 | 99.9 | 99.7 | 99.7 | true |
| 1 | 4 | 2 | weir | 110872 | 0 | 110872 | 0 | 3695.5 | 1.791 | 50.0 | 0.0 | 99.3 | true |
| 1 | 4 | 3 | direct | 246260 | 0 | 246260 | 0 | 8208.3 | 0.639 | 99.8 | 99.5 | 99.5 | true |
| 1 | 4 | 3 | weir | 107106 | 0 | 107106 | 0 | 3570.0 | 1.919 | 49.2 | 0.0 | 99.7 | true |
| 1 | 128 | 1 | direct | 247150 | 0 | 247150 | 0 | 8235.5 | 57.343 | 100.2 | 97.3 | 97.3 | true |
| 1 | 128 | 1 | weir | 295825 | 0 | 295825 | 0 | 9857.9 | 24.575 | 28.1 | 0.0 | 96.9 | true |
| 1 | 128 | 2 | direct | 254833 | 0 | 254833 | 0 | 8492.1 | 53.247 | 100.1 | 97.0 | 97.0 | true |
| 1 | 128 | 2 | weir | 309742 | 0 | 309742 | 0 | 10318.9 | 24.575 | 27.6 | 0.0 | 99.9 | true |
| 1 | 128 | 3 | direct | 266254 | 0 | 266254 | 0 | 8872.2 | 53.247 | 100.1 | 97.0 | 97.0 | true |
| 1 | 128 | 3 | weir | 313342 | 0 | 313342 | 0 | 10442.3 | 24.575 | 27.2 | 0.0 | 100.0 | true |

Measured Weir adapter and streaming RPC evidence (warmup, reset and postflight excluded):

| Batch | Workers | Round | Adapter invocations | Mean adapter batch | Execute RPCs | Queue mean ms | Adapter mean ms | Rejections |
| ---: | ---: | ---: | ---: | ---: | --- | ---: | ---: | ---: |
| 1 | 4 | 1 | 104220 | 1.048 | 109266 | 0.013 | 0.419 | 0 |
| 1 | 4 | 2 | 105846 | 1.047 | 110872 | 0.013 | 0.415 | 0 |
| 1 | 4 | 3 | 102096 | 1.049 | 107106 | 0.014 | 0.425 | 0 |
| 1 | 128 | 1 | 33382 | 8.862 | 295825 | 1.111 | 1.999 | 0 |
| 1 | 128 | 2 | 36998 | 8.372 | 309742 | 1.069 | 1.812 | 0 |
| 1 | 128 | 3 | 36649 | 8.550 | 313342 | 1.049 | 1.808 | 0 |

**Batch 1: database-full-load throughput comparison unavailable.** both paths must independently demonstrate sustained database CPU saturation and a verified next-level throughput plateau; increase concurrency or isolate client/Weir resources; I/O/network-bound saturation needs additional device/link capacity evidence.

Best verified business QPS within this ladder: direct 8533.3 (128 workers), Weir 10206.3 (128 workers), observed change +19.61%. This is a measured business-throughput comparison, not a maximum-database-capacity claim.

Observed single-request business performance at matched client concurrency (independent of the database-capacity qualification):

| Workers | Direct QPS | Weir QPS | Change | Direct p50/p95/p99 ms | Weir p50/p95/p99 ms |
| ---: | ---: | ---: | ---: | --- | --- |
| 4 | 8246.2 | 3635.8 | -55.91% | 0.383 / 0.639 / 0.959 | 1.023 / 1.791 / 2.559 |
| 128 | 8533.3 | 10206.3 | +19.61% | 9.215 / 53.247 / 61.439 | 12.287 / 24.575 / 32.767 |

These QPS and latency observations apply to this hardware and measured concurrency range. A business-throughput improvement can exist without demonstrating the maximum database capacity. An underfull database or missing next-level plateau keeps the database-capacity comparison unavailable.

Aggregation evidence: the JSON records one business request per record, Execute RPC counts, adapter invocation counts, average adapter batch and its cumulative histogram, and RPCs per adapter invocation. An adapter invocation is not necessarily one physical database wire command. MongoDB physical find/update/bulkWrite/getMore/killCursors/commitTransaction/abortTransaction deltas come from owned serverStatus at timed boundaries; missing counters remain unavailable. Elasticsearch has no equivalent physical HTTP-command counter. Every child PID, configured native pool limit, final revision ranges, exit result and sampled CPU/RSS is retained; coordinator sampling CPU is excluded from business-client CPU.

The JSON retains before/after raw public Weir metrics and their observed deltas, every resource sample, monitor failures, raw cumulative database/container I/O and network counters, CPU quota/host core denominator, and client/Weir cumulative CPU. Docker CPU uses cumulative Engine usage and read timestamps across each entire sampling interval, never CLI instantaneous percentages. Both interval endpoints must succeed; missing intervals reduce full-run coverage. Samples include monitoring traffic and background database work. Native ps CPU has platform-dependent clock resolution. Native databases share the host CPU budget with the client and Weir. Disk/network utilization or capacity is not inferred from byte counters. A plateau without sustained database CPU saturation is not a database-full-load result. Startup/discovery/reset/postflight and warmup are excluded from throughput; all in-flight completion and validation is included.

Resource observation schema 2 additionally retains bounded Linux host CPU ticks (busy, idle, iowait and steal, without double-counted guest ticks), CPU/IO/memory pressure, the sampler's allowed CPU list and runtime parallelism, Docker cumulative throttling counters, fixed sampled Store queue/execution gauges, and projected Search write-pool/indexing-pressure/GC statistics. Host/device evidence includes other runner work; sampler affinity is not a promise that all child processes have that affinity. Missing or unsupported fields remain explicitly unavailable. Pure Search stages retain before/after effective index settings and owned-index indexing/refresh/merge/flush/translog statistics, with explicit 1s refresh and request durability. Lucene flush statistics are not counts or timings of per-request translog fsync. No added metric alone establishes database or storage capacity.
