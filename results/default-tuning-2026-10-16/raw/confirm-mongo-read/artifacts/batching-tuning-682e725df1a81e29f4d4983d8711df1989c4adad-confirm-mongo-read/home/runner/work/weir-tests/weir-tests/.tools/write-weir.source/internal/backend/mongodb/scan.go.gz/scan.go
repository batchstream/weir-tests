package mongodb

import (
	"context"
	"encoding/binary"
	"fmt"
	"strings"

	"github.com/batchstream/weir-protocol/api/protocol"
	pb "github.com/batchstream/weir-protocol/api/weir/v1"
	"github.com/batchstream/weir/internal/execution"
	"go.mongodb.org/mongo-driver/v2/bson"
	"go.mongodb.org/mongo-driver/v2/x/bsonx/bsoncore"
	"google.golang.org/protobuf/proto"
)

// The driver enforces its advertised native message size before allocating.
// Working-byte estimates are separate from output-frame ownership.
const scanPageBudget = 24 << 20

// A Scan retains the driver reply and a copied output prefix while validating.
const scanWorkingBytes = 48 << 20

// This profile fixes the checkpoint shape and ascending native BSON _id order.
// Scheduling and native batch limits are deliberately outside the profile.
const scanProfile = "mongodb:v1"

type scanPlan struct {
	limits execution.ScanLimits
	execution.ScanProgress
	target            namespace
	options           bson.D
	filter            bson.RawValue
	last              bson.Raw
	fingerprint       string
	pageSize          uint64
	batchSize         int
	qualified, closed bool
	includeID         bool
}

func (a *Adapter) prepareScan(req *pb.ScanRequest) (*execution.Plan, *pb.Failure) {
	if f := protocol.ValidateScan(req); f != nil {
		return nil, f
	}
	parts, _ := protocol.ParseRelativeResource(req.Resource)
	if len(parts) != 2 || !validNamespace(parts) {
		return nil, protocol.Fail(pb.FailureCode_INVALID_ARGUMENT, "invalid MongoDB Scan target")
	}
	target := namespace{database: parts[0], collection: parts[1]}
	native := &scanPlan{target: target, pageSize: protocol.ScanPageSize(req), batchSize: a.options().Scan.Documents, limits: a.options().Scan, fingerprint: protocol.ScanFingerprint(req, a.config.Store, scanProfile), includeID: true}
	if d := req.Filter; d != nil {
		if d.ContentType != "application/bson" {
			return nil, protocol.Fail(pb.FailureCode_UNSUPPORTED, "MongoDB Scan filter requires BSON")
		}

		if !validScanBSON(d.Data, 0) {
			return nil, protocol.Fail(pb.FailureCode_INVALID_ARGUMENT, "invalid or excessive BSON filter")
		}
		native.filter = bson.RawValue{Type: bson.TypeEmbeddedDocument, Value: d.Data}
	}
	if projection := req.Projection; projection != nil {
		fields := bson.D{}
		include := projection.Mode == pb.ProjectionMode_INCLUDE
		native.includeID = !include
		for _, name := range projection.Fields {
			for _, segment := range strings.Split(name, ".") {
				if strings.HasPrefix(segment, "$") {
					return nil, protocol.Fail(pb.FailureCode_UNSUPPORTED, "MongoDB Scan projection does not support dollar-prefixed fields")
				}
			}
			if strings.HasPrefix(name, "_id.") {
				return nil, protocol.Fail(pb.FailureCode_UNSUPPORTED, "MongoDB Scan projects the complete _id or excludes it")
			}
			if name == "_id" {
				native.includeID = include
				continue
			}
			flag := int32(0)
			if include {
				flag = 1
			}
			field := bson.E{Key: name, Value: flag}
			fields = append(fields, field)
		}
		if include {
			identity := bson.E{Key: "_id", Value: int32(1)}
			fields = append(fields, identity)
		}
		if len(fields) != 0 {
			option := bson.E{Key: "projection", Value: fields}
			native.options = append(native.options, option)
		}
	}
	if len(req.ContinuationToken) != 0 {
		state, err := protocol.DecodeScanToken(req.ContinuationToken, scanProfile, native.fingerprint)
		if err != nil || !validScanID(state) {
			return nil, protocol.Fail(pb.FailureCode_INVALID_ARGUMENT, "invalid or mismatched MongoDB Scan continuation")
		}
		native.last = state
	}
	p := &execution.Plan{
		Key:          req.Resource,
		Bytes:        proto.Size(req) + execution.EntryOverheadBytes + 4096,
		ResultBytes:  max(a.options().Scan.ResultBytes(), a.documentBytes()+execution.ResultOverheadBytes),
		WorkingBytes: scanWorkingBytes,
		Backend:      native,
	}
	return p, nil
}

func scanFindCommand(n *scanPlan) bson.D {
	batchSize := min(n.pageSize-n.Count, uint64(n.limits.Documents), uint64(n.batchSize))
	order := bson.D{{Key: "_id", Value: int32(1)}}
	command := bson.D{
		{Key: "find", Value: n.target.collection},
		{Key: "sort", Value: order},
		{Key: "hint", Value: order},
		{Key: "limit", Value: int64(batchSize)},
		{Key: "batchSize", Value: int32(batchSize)},
		{Key: "singleBatch", Value: true},
		{Key: "allowPartialResults", Value: false},
	}
	command = append(command, n.options...)
	filter := any(n.filter)
	if n.filter.Type == 0 {
		filter = bson.D{}
	}
	if len(n.last) != 0 {
		id := n.last.Lookup("_id")
		// Expression comparison uses the full BSON order. Native $gt applies
		// type bracketing, while find.min has an exclusive MaxKey upper bound.
		// $literal preserves dollar-prefixed strings and embedded document IDs.
		literal := bson.D{{Key: "$literal", Value: id}}
		greater := bson.D{{Key: "$gt", Value: bson.A{"$_id", literal}}}
		boundary := bson.D{{Key: "$expr", Value: greater}}
		both := bson.D{{Key: "$and", Value: bson.A{filter, boundary}}}
		filter = both
	}
	element := bson.E{Key: "filter", Value: filter}
	command = append(command, element)
	return command
}

func (a *Adapter) fetchScan(ctx context.Context, p *execution.Plan) *execution.ScanPage {
	n := p.Backend.(*scanPlan)
	page := &execution.ScanPage{}
	if n.closed || ctx.Err() != nil {
		page.Failure = protocol.ContextFailure(ctx)
		return page
	}
	if n.Count >= n.pageSize {
		page.Failure = protocol.Fail(pb.FailureCode_INTERNAL, "Scan fetched beyond its logical page")
		return page
	}
	if !n.qualified {
		if failure := a.qualifyTarget(ctx, n.target); failure != nil {
			page.Failure = failure
			return page
		}
		n.qualified = true
	}
	command := scanFindCommand(n)
	raw, err := a.client.Database(n.target.database).RunCommand(ctx, command).Raw()
	if err != nil {
		page.Failure = backendFailure(ctx, err)
		return page
	}
	batchSize := min(n.pageSize-n.Count, uint64(a.options().Scan.Documents), uint64(n.batchSize))
	cursor := &recordCursor{target: n.target, items: int(batchSize), outputBytes: a.options().Scan.Bytes}
	page = a.recordCursorReply(raw, cursor, true)
	if page.Failure != nil {
		return page
	}
	if cursor.cursor != 0 {
		page.Documents = nil
		page.Exhausted = false
		page.Failure = protocol.Fail(pb.FailureCode_INTERNAL, "single-batch Scan retained a cursor")
		return page
	}
	// singleBatch closes even a byte-truncated native batch. Only an empty
	// response proves exhaustion; any discarded tail is fetched again from
	// the last accepted identity.
	page.Exhausted = len(page.Documents) == 0 && !cursor.limited
	if len(page.Documents) != 0 {
		id := bson.Raw(page.Documents[len(page.Documents)-1].Data).Lookup("_id")
		identity := bson.D{{Key: "_id", Value: id}}
		state, err := bson.Marshal(identity)
		if err != nil || !validScanID(state) {
			page.Documents = nil
			page.Failure = protocol.Fail(pb.FailureCode_INTERNAL, "invalid Scan _id")
			return page
		}
		n.last = state
	}
	if !n.includeID {
		for _, document := range page.Documents {
			start, output := bsoncore.AppendDocumentStart(nil)
			remaining := document.Data[4 : len(document.Data)-1]
			for len(remaining) != 0 {
				element, tail, _ := bsoncore.ReadElement(remaining)
				remaining = tail
				if element.Key() != "_id" {
					output = append(output, element...)
				}
			}
			output, _ = bsoncore.AppendDocumentEnd(output, start)
			document.Data = output
		}
	}
	if cursor.limited {
		// Learn from the accepted byte-bounded prefix, not a short logical page.
		// Subsequent fetches in this logical page reuse this conservative capacity.
		n.batchSize = max(1, len(page.Documents))
	}
	if !page.Exhausted && n.Count+uint64(len(page.Documents)) >= n.pageSize {
		token, err := protocol.EncodeScanToken(scanProfile, n.fingerprint, n.last)
		if err != nil {
			page.Documents = nil
			page.Failure = protocol.Fail(pb.FailureCode_INTERNAL, "cannot encode Scan continuation")
			return page
		}
		page.Complete = true
		page.NextContinuationToken = token
	}
	return page
}

func validScanID(raw []byte) bool {

	if !validScanBSON(raw, 0) {
		return false
	}
	fields, err := scanFields(raw)
	if err != nil || len(fields) != 1 {
		return false
	}
	id, exists := fields["_id"]
	return exists && id.Type != bson.TypeArray && id.Type != bson.TypeRegex && id.Type != bson.TypeUndefined && id.Type != 0
}

func (a *Adapter) closeScan(_ context.Context, p *execution.Plan) *pb.Failure {
	state := p.Backend.(*scanPlan)
	state.closed = true
	state.options = nil
	state.filter = bson.RawValue{}
	state.last = nil
	return nil
}

func scanOK(value bson.RawValue) bool {
	switch value.Type {
	case bson.TypeDouble:
		return value.Double() == 1
	case bson.TypeInt32:
		return value.Int32() == 1
	case bson.TypeInt64:
		return value.Int64() == 1
	}
	return false
}

// Validation walks bounded raw bytes; it never builds a native document tree or
// converts BSON types. MongoDB's native maximum nesting depth is 100.
func validScanBSON(raw []byte, depth int) bool {
	if depth > 100 || !scanFraming(raw) {
		return false
	}
	rest := raw[4 : len(raw)-1]
	for len(rest) > 0 {
		element, tail, ok := bsoncore.ReadElement(rest)
		if !ok {
			return false
		}
		rest = tail
		value, err := element.ValueErr()
		if err != nil {
			return false
		}
		switch value.Type {
		case bsoncore.TypeEmbeddedDocument, bsoncore.TypeArray:
			if !validScanBSON(value.Data, depth+1) {
				return false
			}
		case bsoncore.TypeCodeWithScope:
			_, scope, ok := value.CodeWithScopeOK()
			if !ok || !validScanBSON(scope, depth+1) {
				return false
			}
		default:
			if value.Validate() != nil {
				return false
			}
		}
	}
	return true
}

func scanFraming(raw []byte) bool {
	return len(raw) >= 5 && int64(binary.LittleEndian.Uint32(raw)) == int64(len(raw)) && raw[len(raw)-1] == 0
}

func scanFields(raw []byte) (map[string]bson.RawValue, error) {
	if !scanFraming(raw) {
		return nil, fmt.Errorf("invalid BSON framing")
	}
	fields := make(map[string]bson.RawValue)
	rest := raw[4 : len(raw)-1]
	for len(rest) > 0 {
		element, tail, ok := bsoncore.ReadElement(rest)
		if !ok {
			return nil, fmt.Errorf("invalid element")
		}
		rest = tail
		key, err := element.KeyErr()
		if err != nil {
			return nil, err
		}
		if _, exists := fields[key]; exists {
			return nil, fmt.Errorf("duplicate field")
		}
		value, err := element.ValueErr()
		if err != nil {
			return nil, err
		}
		fields[key] = bson.RawValue{Type: bson.Type(value.Type), Value: value.Data}
	}
	return fields, nil
}
