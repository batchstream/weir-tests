# Database saturation comparison

Backend **mongo**. Started 2026-10-15T18:02:17.249348326Z.

independent OS client processes send one record per native call or streaming SDK RPC; native FindOne/ReplaceOne or single-ID mget/PUT; no client aggregation; worker-owned disjoint IDs; common phase barriers and unchanged pools across warmup and measurement; alternating AB/BA; latency is each business request including validation, queueing and any server aggregation; independent persisted postflight; Search uses explicit refresh_interval=1s, translog.durability=request, one primary and zero replicas; sustained database CPU requires >=5 intervals, >=80% measurement coverage, mean CPU>=threshold and CPU>=threshold during >=80% measurement duration in every round, plus <=10% next-level throughput gain.

Warmup 30s and measurement 30s per path/stage, 3 paired rounds, requested writes 0%.

Complete business-request budget for both paths: 10s.

4 independent OS client processes. Each worker sends one business request containing one record, waits for its acknowledged result, and validates it. p50/p95/p99 describe individual requests; histograms are pooled rather than averaging process quantiles.

| Batch | Workers | Round | Path | Read | Write | Success | Errors/unknown | Ops/s | p95 call ms | DB CPU budget % | Full CPU time % | Sampling coverage % | Verified |
| ---: | ---: | ---: | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | --- |
| 1 | 4 | 1 | direct | 247967 | 0 | 247967 | 0 | 8265.3 | 0.639 | 99.9 | 99.6 | 99.6 | true |
| 1 | 4 | 1 | weir | 110798 | 0 | 110798 | 0 | 3693.0 | 1.791 | 50.4 | 0.0 | 99.5 | true |
| 1 | 4 | 2 | direct | 247898 | 0 | 247898 | 0 | 8263.0 | 0.639 | 99.9 | 99.6 | 99.6 | true |
| 1 | 4 | 2 | weir | 103548 | 0 | 103548 | 0 | 3451.3 | 2.047 | 48.3 | 0.0 | 99.9 | true |
| 1 | 4 | 3 | direct | 246370 | 0 | 246370 | 0 | 8212.0 | 0.639 | 99.9 | 99.0 | 99.0 | true |
| 1 | 4 | 3 | weir | 104280 | 0 | 104280 | 0 | 3475.8 | 1.919 | 48.0 | 0.0 | 99.8 | true |
| 1 | 128 | 1 | direct | 239903 | 0 | 239903 | 0 | 7983.1 | 57.343 | 100.2 | 98.3 | 98.3 | true |
| 1 | 128 | 1 | weir | 296098 | 0 | 296098 | 0 | 9865.9 | 24.575 | 27.5 | 0.0 | 97.0 | true |
| 1 | 128 | 2 | direct | 230926 | 0 | 230926 | 0 | 7695.0 | 57.343 | 100.1 | 98.0 | 98.0 | true |
| 1 | 128 | 2 | weir | 297560 | 0 | 297560 | 0 | 9915.7 | 24.575 | 27.0 | 0.0 | 96.7 | true |
| 1 | 128 | 3 | direct | 245206 | 0 | 245206 | 0 | 8170.4 | 57.343 | 100.1 | 97.6 | 97.6 | true |
| 1 | 128 | 3 | weir | 307203 | 0 | 307203 | 0 | 10236.6 | 24.575 | 26.1 | 0.0 | 96.5 | true |

Measured Weir adapter and streaming RPC evidence (warmup, reset and postflight excluded):

| Batch | Workers | Round | Adapter invocations | Mean adapter batch | Execute RPCs | Queue mean ms | Adapter mean ms | Rejections |
| ---: | ---: | ---: | ---: | ---: | --- | ---: | ---: | ---: |
| 1 | 4 | 1 | 105972 | 1.046 | 110798 | 0.013 | 0.413 | 0 |
| 1 | 4 | 2 | 98746 | 1.049 | 103548 | 0.014 | 0.438 | 0 |
| 1 | 4 | 3 | 99276 | 1.050 | 104280 | 0.015 | 0.436 | 0 |
| 1 | 128 | 1 | 32993 | 8.975 | 296098 | 1.055 | 1.915 | 0 |
| 1 | 128 | 2 | 32377 | 9.190 | 297560 | 1.066 | 1.906 | 0 |
| 1 | 128 | 3 | 33293 | 9.227 | 307203 | 1.039 | 1.844 | 0 |

**Batch 1: database-full-load throughput comparison unavailable.** both paths must independently demonstrate sustained database CPU saturation and a verified next-level throughput plateau; increase concurrency or isolate client/Weir resources; I/O/network-bound saturation needs additional device/link capacity evidence.

Best verified business QPS within this ladder: direct 8246.7 (4 workers), Weir 10006.1 (128 workers), observed change +21.33%. This is a measured business-throughput comparison, not a maximum-database-capacity claim.

Observed single-request business performance at matched client concurrency (independent of the database-capacity qualification):

| Workers | Direct QPS | Weir QPS | Change | Direct p50/p95/p99 ms | Weir p50/p95/p99 ms |
| ---: | ---: | ---: | ---: | --- | --- |
| 4 | 8246.7 | 3540.1 | -57.07% | 0.383 / 0.639 / 0.895 | 1.151 / 1.919 / 2.559 |
| 128 | 7949.5 | 10006.1 | +25.87% | 10.239 / 57.343 / 61.439 | 12.287 / 24.575 / 32.767 |

These QPS and latency observations apply to this hardware and measured concurrency range. A business-throughput improvement can exist without demonstrating the maximum database capacity. An underfull database or missing next-level plateau keeps the database-capacity comparison unavailable.

Aggregation evidence: the JSON records one business request per record, Execute RPC counts, adapter invocation counts, average adapter batch and its cumulative histogram, and RPCs per adapter invocation. An adapter invocation is not necessarily one physical database wire command. MongoDB physical find/update/bulkWrite/getMore/killCursors/commitTransaction/abortTransaction deltas come from owned serverStatus at timed boundaries; missing counters remain unavailable. Elasticsearch has no equivalent physical HTTP-command counter. Every child PID, configured native pool limit, final revision ranges, exit result and sampled CPU/RSS is retained; coordinator sampling CPU is excluded from business-client CPU.

The JSON retains before/after raw public Weir metrics and their observed deltas, every resource sample, monitor failures, raw cumulative database/container I/O and network counters, CPU quota/host core denominator, and client/Weir cumulative CPU. Docker CPU uses cumulative Engine usage and read timestamps across each entire sampling interval, never CLI instantaneous percentages. Both interval endpoints must succeed; missing intervals reduce full-run coverage. Samples include monitoring traffic and background database work. Native ps CPU has platform-dependent clock resolution. Native databases share the host CPU budget with the client and Weir. Disk/network utilization or capacity is not inferred from byte counters. A plateau without sustained database CPU saturation is not a database-full-load result. Startup/discovery/reset/postflight and warmup are excluded from throughput; all in-flight completion and validation is included.

Resource observation schema 2 additionally retains bounded Linux host CPU ticks (busy, idle, iowait and steal, without double-counted guest ticks), CPU/IO/memory pressure, the sampler's allowed CPU list and runtime parallelism, Docker cumulative throttling counters, fixed sampled Store queue/execution gauges, and projected Search write-pool/indexing-pressure/GC statistics. Host/device evidence includes other runner work; sampler affinity is not a promise that all child processes have that affinity. Missing or unsupported fields remain explicitly unavailable. Pure Search stages retain before/after effective index settings and owned-index indexing/refresh/merge/flush/translog statistics, with explicit 1s refresh and request durability. Lucene flush statistics are not counts or timings of per-request translog fsync. No added metric alone establishes database or storage capacity.
