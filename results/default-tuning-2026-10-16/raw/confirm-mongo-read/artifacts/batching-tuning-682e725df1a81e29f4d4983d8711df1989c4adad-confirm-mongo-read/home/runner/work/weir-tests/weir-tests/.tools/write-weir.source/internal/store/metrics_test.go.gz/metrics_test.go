package store

import (
	"context"
	"testing"
	"time"

	"github.com/batchstream/weir-protocol/api/protocol"
	pb "github.com/batchstream/weir-protocol/api/weir/v1"
	"github.com/batchstream/weir/internal/execution"
	"github.com/batchstream/weir/internal/testutil/testmetrics"
)

type metricAdapter struct{ scanTestAdapter }

func (a *metricAdapter) Execute(_ context.Context, plans []*execution.Plan, emit execution.Emit) bool {
	results := make([]*pb.Event, len(plans))
	outcomes := []pb.MutationOutcome{pb.MutationOutcome_APPLIED, pb.MutationOutcome_NOT_APPLIED, pb.MutationOutcome_UNKNOWN}
	for i, p := range plans {
		var failure *pb.Failure
		if i > 0 {
			failure = protocol.Fail(pb.FailureCode_UNAVAILABLE, "private backend error")
		}
		results[i] = execution.FailedEvent(p.Command, outcomes[i], failure)
	}
	for i, result := range results {
		output := result
		_ = emit(plans[i], output)
	}
	return false
}
func TestMetricsExactBatchOutcomesAdmissionAndConfiguredCapacity(t *testing.T) {
	limits := DefaultLimits()
	limits.QueueBytes = (9 << 20)
	limits.BatchOperations = 3
	limits.BatchBytes = 8 << 20
	adapter := &metricAdapter{}
	r := newRuntime(adapter, limits)
	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()
	var tickets []*Ticket
	for i, key := range []string{"a", "b", "c", "d"} {
		p := plan(uint64(i), key, false)
		p.Bytes = limits.QueueBytes / 4
		ticket, f, _ := r.Submit(ctx, p, nil)
		if f != nil {
			t.Fatal(f)
		}
		tickets = append(tickets, ticket)
	}
	p := plan(4, "rejected", false)
	p.Bytes = limits.QueueBytes / 4
	if _, f, _ := r.Submit(ctx, p, nil); f == nil {
		t.Fatal("missing rejection")
	}
	session := r.NewSession()
	defer session.Close()
	for range 5 {
		if _, f, _ := r.Submit(ctx, p, session); f == nil {
			t.Fatal("missing capacity wait")
		}
	}
	r.mu.Lock()
	b, _ := r.selectLocked(time.Now())
	r.mu.Unlock()
	r.execute(b)
	ready := testmetrics.Gather(t, r)
	if testmetrics.Sum(ready, "weir_store_retained_results") != 3 || testmetrics.Sum(ready, "weir_store_retained_result_reserved_bytes") != 3*execution.ResultOverheadBytes {
		t.Fatal("ready result byte reservations")
	}
	cancel()
	r.mu.Lock()
	r.cancelQueuedLocked()
	r.mu.Unlock()
	for _, ticket := range tickets {
		ticket.Ack()
	}
	for range 3 {
		families := testmetrics.Gather(t, r)
		for _, outcome := range []string{"applied", "not_applied", "unknown", "not_started"} {
			labels := map[string]string{"operation": "mutate", "outcome": outcome}
			if got := testmetrics.Sample(families, "weir_store_records_total", labels).GetCounter().GetValue(); got != 1 {
				t.Fatal(outcome, got)
			}
		}
		if testmetrics.Sum(families, "weir_store_executions_total") != 1 || testmetrics.Sum(families, "weir_store_rejections_total") != 1 {
			t.Fatal("physical/rejection counts")
		}
		h := testmetrics.Sample(families, "weir_store_batch_operations", nil).GetHistogram()
		if h.GetSampleCount() != 1 || h.GetSampleSum() != 3 {
			t.Fatal("batch count/size", h)
		}
		if testmetrics.Sum(families, "weir_store_pending_entries") != 0 || testmetrics.Sum(families, "weir_store_result_reserved_entries") != 0 {
			t.Fatal("ledger not released")
		}
	}
	families := testmetrics.Gather(t, r)
	if testmetrics.Sum(families, "weir_store_pending_entries_limit") != float64(limits.QueueOperations) {
		t.Fatal("configured concurrency metric changed")
	}
	if testmetrics.Sum(families, "weir_store_active_executions_limit") != float64(limits.MaxInFlight) {
		t.Fatal("configured in-flight batch limit missing")
	}
	if testmetrics.Sum(families, "weir_store_batch_max_wait_seconds") != limits.BatchWait.Seconds() {
		t.Fatal("configured collection wait missing")
	}
	if testmetrics.Sum(families, "weir_store_batch_max_operations") != float64(limits.BatchOperations) || testmetrics.Sum(families, "weir_store_batch_max_bytes") != float64(limits.BatchBytes) {
		t.Fatal("configured batch count or byte limit missing")
	}
	if testmetrics.Series(families) != 53 {
		t.Fatal("Store series changed", testmetrics.Series(families))
	}
}
