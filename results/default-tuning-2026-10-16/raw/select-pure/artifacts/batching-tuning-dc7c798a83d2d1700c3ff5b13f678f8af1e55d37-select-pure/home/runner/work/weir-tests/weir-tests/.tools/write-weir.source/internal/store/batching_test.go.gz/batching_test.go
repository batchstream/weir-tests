package store

import (
	"context"
	"testing"
	"time"

	"github.com/batchstream/weir-protocol/api/protocol"
	pb "github.com/batchstream/weir-protocol/api/weir/v1"
	"github.com/batchstream/weir/internal/execution"
)

var recordActions = []string{"read", "put", "create", "replace", "delete", "expression", "program"}

func recordActionPlan(index uint64, key, action string) *execution.Plan {
	p := plan(index, key, action == "read")
	if action == "read" || action == "delete" {
		return p
	}
	m := p.Command.GetMutate()
	doc := &pb.Document{ContentType: "application/json", Data: []byte(`{"n":1}`)}
	switch action {
	case "put":
		m.Action = &pb.MutateRequest_Put{Put: doc}
	case "create":
		m.Action = &pb.MutateRequest_Create{Create: doc}
	case "replace":
		m.Action = &pb.MutateRequest_Replace{Replace: doc}
	case "expression":
		form := &pb.Transform_BackendExpression{BackendExpression: doc}
		transform := &pb.Transform{Form: form}
		m.Action = &pb.MutateRequest_AtomicTransform{AtomicTransform: transform}
	case "program":
		program := &pb.LuaTransform{Source: []byte(`return function(current, incoming) return weir.keep() end`)}
		form := &pb.Transform_Lua{Lua: program}
		transform := &pb.Transform{Form: form}
		m.Action = &pb.MutateRequest_AtomicTransform{AtomicTransform: transform}
	default:
		panic("unknown record action")
	}
	return p
}

func TestAllRecordActionsShareBatch(t *testing.T) {
	limits := DefaultLimits()
	r := newRuntime(nil, limits)
	session := r.NewSession()
	defer session.Close()
	for i, action := range recordActions {
		p := recordActionPlan(uint64(i), action+"/record", action)
		var s *Session
		if i%2 == 0 {
			s = session
		}
		if _, failure, _ := r.Submit(context.Background(), p, s); failure != nil {
			t.Fatal(failure)
		}
	}
	r.mu.Lock()
	b, _ := r.selectLocked(time.Now())
	r.mu.Unlock()
	if b == nil || len(b.items) != len(recordActions) {
		t.Fatalf("all reads and mutations should share one batch: %v", b)
	}
	for i, ticket := range b.items {
		if ticket.plan.ID != uint64(i) {
			t.Fatal("mixed batch changed operation identity")
		}
	}
	r.mu.Lock()
	finish(r, b)
	r.mu.Unlock()
	for _, ticket := range b.items {
		ticket.Ack()
	}
	if snapshot := r.Snapshot(); snapshot.Retained != 0 || snapshot.Pending != 0 || snapshot.Active != 0 {
		t.Fatal("mixed batch leaked admission credits", snapshot)
	}
}

func TestMixedBatchRespectsBytesKeysAndSessionOrder(t *testing.T) {
	limits := DefaultLimits()
	limits.BatchOperations = 3
	r := newRuntime(nil, limits)
	session := r.NewSession()
	defer session.Close()
	firstWrite := recordActionPlan(0, "same", "put")
	replace := recordActionPlan(1, "same", "replace")
	expression := recordActionPlan(2, "other", "expression")
	program := recordActionPlan(3, "last", "program")
	for _, p := range []*execution.Plan{firstWrite, replace, expression, program} {
		p.Bytes = limits.BatchBytes / 2
		if _, failure, _ := r.Submit(context.Background(), p, session); failure != nil {
			t.Fatal(failure)
		}
	}
	independent := recordActionPlan(0, "same", "read")
	independent.Bytes = limits.BatchBytes / 2
	ticket, failure, _ := r.Submit(context.Background(), independent, nil)
	if failure != nil {
		t.Fatal(failure)
	}
	r.mu.Lock()
	first, _ := r.selectLocked(time.Now())
	r.mu.Unlock()
	if first == nil || len(first.items) != 2 || first.items[0].plan != firstWrite || first.items[1].plan != expression {
		t.Fatal("record duplicate or byte limit ignored", first)
	}
	r.mu.Lock()
	second, _ := r.selectLocked(time.Now())
	r.mu.Unlock()
	if second == nil || len(second.items) != 2 || second.items[0].plan != program || second.items[1] != ticket {
		t.Fatal("active session successor ran or independent record was blocked", second)
	}
	r.mu.Lock()
	premature, _ := r.selectLocked(time.Now())
	r.mu.Unlock()
	if premature != nil {
		t.Fatal("Replace bypassed its earlier same-session mutation")
	}
	r.mu.Lock()
	finish(r, first)
	third, _ := r.selectLocked(time.Now())
	r.mu.Unlock()
	if third == nil || len(third.items) != 1 || third.items[0].plan != replace {
		t.Fatal("same-session successor not released", third)
	}
	r.mu.Lock()
	finish(r, second)
	finish(r, third)
	r.mu.Unlock()
	ticket.Ack()
}

type recordBatchAdapter struct {
	scanTestAdapter
	started chan []*execution.Plan
	phases  chan *execution.Plan
	gate    <-chan struct{}
}

func (a *recordBatchAdapter) Execute(ctx context.Context, plans []*execution.Plan, emit execution.Emit) bool {
	a.started <- plans
	select {
	case <-a.gate:
	case <-ctx.Done():
	}
	results := make([]*pb.Event, len(plans))
	for i, p := range plans {
		outcome := pb.MutationOutcome_APPLIED
		var failure *pb.Failure
		if p.Context.Err() != nil {
			outcome = pb.MutationOutcome_NOT_STARTED
			failure = protocol.ContextFailure(p.Context)
		} else if a.phases != nil {
			a.phases <- p
		}
		results[i] = execution.FailedEvent(p.Command, outcome, failure)
	}
	for i, result := range results {
		output := result
		_ = emit(plans[i], output)
	}
	return false
}

func TestDispatchContextsDoNotMutateReusablePlans(t *testing.T) {
	gate := make(chan struct{})
	defer func() {
		select {
		case <-gate:
		default:
			close(gate)
		}
	}()
	adapter := &recordBatchAdapter{started: make(chan []*execution.Plan, 2), gate: gate}
	limits := DefaultLimits()
	r := newRuntime(adapter, limits)
	p := recordActionPlan(0, "same", "replace")
	firstContext, cancelFirst := context.WithCancel(context.Background())
	defer cancelFirst()
	secondContext, cancelSecond := context.WithCancel(context.Background())
	defer cancelSecond()
	first, failure, _ := r.Submit(firstContext, p, nil)
	if failure != nil {
		t.Fatal(failure)
	}
	second, failure, _ := r.Submit(secondContext, p, nil)
	if failure != nil {
		t.Fatal(failure)
	}
	r.mu.Lock()
	a, _ := r.selectLocked(time.Now())
	b, _ := r.selectLocked(time.Now())
	r.mu.Unlock()
	go r.execute(a)
	dispatchedFirst := <-adapter.started
	go r.execute(b)
	dispatchedSecond := <-adapter.started
	if p.Context != nil || dispatchedFirst[0] == p || dispatchedSecond[0] == p || dispatchedFirst[0] == dispatchedSecond[0] {
		t.Fatal("dispatch modified a reusable prepared plan")
	}
	if dispatchedFirst[0].Context != first.ctx || dispatchedSecond[0].Context != second.ctx {
		t.Fatal("caller contexts were crossed between dispatches")
	}
	cancelFirst()
	if dispatchedSecond[0].Context.Err() != nil || b.ctx.Err() != nil {
		t.Fatal("one caller cancellation poisoned independent execution")
	}
	close(gate)
	if recordEvent(t, first).GetMutationResult().Outcome != pb.MutationOutcome_NOT_STARTED || recordEvent(t, second).GetMutationResult().Outcome != pb.MutationOutcome_APPLIED {
		t.Fatal("caller cancellation lost per-item identity")
	}
	first.Ack()
	second.Ack()
}

func TestAbandonAndSessionCloseCancelFuturePhasesOnly(t *testing.T) {
	for _, closeSession := range []bool{false, true} {
		name := "abandon"
		if closeSession {
			name = "session_close"
		}
		t.Run(name, func(t *testing.T) {
			gate := make(chan struct{})
			defer func() {
				select {
				case <-gate:
				default:
					close(gate)
				}
			}()
			adapter := &recordBatchAdapter{started: make(chan []*execution.Plan, 1), phases: make(chan *execution.Plan, 2), gate: gate}
			limits := DefaultLimits()
			r := newRuntime(adapter, limits)
			original, cancel := context.WithCancel(context.Background())
			defer cancel()
			var session *Session
			if closeSession {
				session = r.NewSession()
				defer session.Close()
			}
			first := recordActionPlan(0, "peer", "create")
			peer, failure, _ := r.Submit(original, first, nil)
			if failure != nil {
				t.Fatal(failure)
			}
			second := recordActionPlan(1, "abandoned", "replace")
			abandoned, failure, _ := r.Submit(original, second, session)
			if failure != nil {
				t.Fatal(failure)
			}
			r.mu.Lock()
			batch, _ := r.selectLocked(time.Now())
			r.mu.Unlock()
			go r.execute(batch)
			dispatched := <-adapter.started
			if len(dispatched) != 2 {
				t.Fatal("test operations did not share a batch")
			}
			if closeSession {
				session.Close()
			} else {
				abandoned.Abandon()
			}
			if dispatched[1].Context.Err() != context.Canceled || dispatched[0].Context.Err() != nil || original.Err() != nil || batch.ctx.Err() != nil {
				t.Fatal("abandonment did not cancel only its own future phases")
			}
			if snapshot := r.Snapshot(); snapshot.Active != 1 || snapshot.Retained != 2 {
				t.Fatal("abandonment released an in-flight reservation", snapshot)
			}
			close(gate)
			if recordEvent(t, peer).GetMutationResult().Outcome != pb.MutationOutcome_APPLIED {
				t.Fatal("abandonment prevented a peer's already admitted work")
			}
			<-abandoned.ready
			peer.Ack()
			if len(adapter.phases) != 1 || (<-adapter.phases).ID != first.ID {
				t.Fatal("abandoned item started its next phase")
			}
			if snapshot := r.Snapshot(); snapshot.Active != 0 || snapshot.Retained != 0 || snapshot.ResultBytes != 0 {
				t.Fatal("terminal abandoned record leaked credits", snapshot)
			}
		})
	}
}
