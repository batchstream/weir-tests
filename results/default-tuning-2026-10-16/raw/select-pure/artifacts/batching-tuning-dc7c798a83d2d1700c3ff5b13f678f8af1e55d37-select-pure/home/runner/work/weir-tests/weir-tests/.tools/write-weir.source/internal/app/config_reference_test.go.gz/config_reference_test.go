package app

import (
	"bytes"
	"os"
	"path/filepath"
	"reflect"
	"strings"
	"testing"

	"github.com/batchstream/weir/internal/testutil"
)

func TestBasicConfigurationFile(t *testing.T) {
	filename := filepath.Join(testutil.Root(t), "config", "weir.reference.yaml")
	cfg, err := Load(filename, "")
	if err != nil {
		t.Fatal("basic configuration must load without routing", err)
	}

	expected := DefaultConfig().Basic.resolved()
	expected.Listeners.Application = "127.0.0.1:7447"
	expected.Diagnostics.Address = "127.0.0.1:7449"
	if !reflect.DeepEqual(cfg.Basic, expected) {
		t.Fatal("basic configuration differs from its documented defaults and addresses")
	}
}

func TestRoutingConfigurationFile(t *testing.T) {
	filename := filepath.Join(testutil.Root(t), "config", "routes.reference.yaml")
	raw, err := os.ReadFile(filename)
	if err != nil {
		t.Fatal(err)
	}
	cfg, err := DecodeRouting(bytes.NewReader(raw))
	if err != nil {
		t.Fatal("Store file must validate without backend IO", err)
	}
	if len(cfg.Stores) != 2 {
		t.Fatal("reference must declare MongoDB and Search Stores")
	}
	for _, definition := range cfg.Stores {
		limits := definition.runtimeLimits()
		if limits.BatchOperations != 32 || limits.BatchBytes != 8<<20 || limits.MaxInFlight != 0 {
			t.Fatal("documented scheduler defaults differ")
		}
		if limits.QueueOperations != 1024 || limits.QueueBytes != 32<<20 {
			t.Fatal("documented working memory or backend timeout differs")
		}
		if definition.Name == "mongo" {
			if definition.Backend.MongoDB == nil || definition.Backend.Search != nil {
				t.Fatal("invalid documented Mongo Store")
			}
		} else if definition.Name == "search" {
			if definition.Backend.Search == nil || definition.Backend.MongoDB != nil {
				t.Fatal("invalid documented Search Store")
			}
			backend := definition.Backend.Search
			if !strings.HasPrefix(backend.URL, "https://") || definition.Backend.Authentication == nil || definition.Backend.Authentication.Username != "weir" || definition.Backend.Authentication.Password != "change-me" || definition.Backend.TLS.CAFile != "/etc/weir/ca.pem" {
				t.Fatal("documented Search HTTPS fields differ")
			}
		} else {
			t.Fatal("unexpected local Store")
		}
	}
}
