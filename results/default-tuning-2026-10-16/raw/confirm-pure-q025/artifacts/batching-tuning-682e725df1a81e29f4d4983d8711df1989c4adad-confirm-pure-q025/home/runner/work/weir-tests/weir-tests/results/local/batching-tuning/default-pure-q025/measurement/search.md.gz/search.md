# Database saturation comparison

Backend **search**. Started 2026-10-15T18:03:38.902625178Z.

independent OS client processes send one record per native call or streaming SDK RPC; native FindOne/ReplaceOne or single-ID mget/PUT; no client aggregation; worker-owned disjoint IDs; common phase barriers and unchanged pools across warmup and measurement; alternating AB/BA; latency is each business request including validation, queueing and any server aggregation; independent persisted postflight; Search uses explicit refresh_interval=1s, translog.durability=request, one primary and zero replicas; sustained database CPU requires >=5 intervals, >=80% measurement coverage, mean CPU>=threshold and CPU>=threshold during >=80% measurement duration in every round, plus <=10% next-level throughput gain.

Warmup 1m0s and measurement 1m0s per path/stage, 3 paired rounds, requested writes 100%.

Complete business-request budget for both paths: 10s.

4 independent OS client processes. Each worker sends one business request containing one record, waits for its acknowledged result, and validates it. p50/p95/p99 describe individual requests; histograms are pooled rather than averaging process quantiles.

| Batch | Workers | Round | Path | Read | Write | Success | Errors/unknown | Ops/s | p95 call ms | DB CPU budget % | Full CPU time % | Sampling coverage % | Verified |
| ---: | ---: | ---: | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | --- |
| 1 | 128 | 1 | direct | 0 | 8264 | 8264 | 0 | 135.5 | 1310.719 | 100.0 | 99.7 | 99.7 | true |
| 1 | 128 | 1 | weir | 0 | 128615 | 128615 | 0 | 2140.0 | 114.687 | 95.2 | 76.8 | 98.5 | true |
| 1 | 128 | 2 | direct | 0 | 34817 | 34817 | 0 | 578.4 | 393.215 | 100.0 | 98.2 | 98.2 | true |
| 1 | 128 | 2 | weir | 0 | 244024 | 244024 | 0 | 4066.0 | 106.495 | 77.8 | 25.2 | 99.2 | true |
| 1 | 128 | 3 | direct | 0 | 37592 | 37592 | 0 | 625.3 | 327.679 | 100.1 | 98.8 | 98.8 | true |
| 1 | 128 | 3 | weir | 0 | 258228 | 258228 | 0 | 4302.1 | 98.303 | 72.0 | 18.0 | 98.6 | true |
| 1 | 512 | 1 | direct | 0 | 38887 | 38887 | 0 | 643.3 | 1048.575 | 99.8 | 98.7 | 98.7 | true |
| 1 | 512 | 1 | weir | 0 | 316485 | 316485 | 0 | 5270.1 | 212.991 | 99.1 | 99.0 | 99.0 | true |
| 1 | 512 | 2 | direct | 0 | 40173 | 40173 | 0 | 664.7 | 1048.575 | 100.0 | 98.3 | 98.3 | true |
| 1 | 512 | 2 | weir | 0 | 269052 | 269052 | 0 | 4480.5 | 229.375 | 99.5 | 98.8 | 98.8 | true |
| 1 | 512 | 3 | direct | 0 | 39730 | 39730 | 0 | 655.7 | 1048.575 | 100.0 | 99.1 | 99.1 | true |
| 1 | 512 | 3 | weir | 0 | 328276 | 328276 | 0 | 5468.2 | 212.991 | 99.1 | 99.3 | 99.3 | true |
| 1 | 1024 | 1 | direct | 0 | 40399 | 40399 | 0 | 661.4 | 1966.079 | 100.1 | 98.4 | 98.4 | true |
| 1 | 1024 | 1 | weir | 0 | 352541 | 352541 | 0 | 5854.2 | 360.447 | 99.1 | 98.3 | 98.3 | true |
| 1 | 1024 | 2 | direct | 0 | 40221 | 40221 | 0 | 658.5 | 2097.151 | 100.0 | 98.9 | 98.9 | true |
| 1 | 1024 | 2 | weir | 0 | 378226 | 378226 | 0 | 6299.9 | 327.679 | 99.4 | 99.2 | 99.2 | true |
| 1 | 1024 | 3 | direct | 0 | 39426 | 39426 | 0 | 644.9 | 1966.079 | 99.9 | 99.1 | 99.1 | true |
| 1 | 1024 | 3 | weir | 0 | 358349 | 358349 | 0 | 5962.7 | 360.447 | 99.4 | 98.4 | 98.4 | true |

Measured Weir adapter and streaming RPC evidence (warmup, reset and postflight excluded):

| Batch | Workers | Round | Adapter invocations | Mean adapter batch | Execute RPCs | Queue mean ms | Adapter mean ms | Rejections |
| ---: | ---: | ---: | ---: | ---: | --- | ---: | ---: | ---: |
| 1 | 128 | 1 | 1097 | 117.242 | 128615 | 6.555 | 43.823 | 0 |
| 1 | 128 | 2 | 1972 | 123.744 | 244024 | 6.129 | 16.235 | 0 |
| 1 | 128 | 3 | 2074 | 124.507 | 258228 | 6.166 | 14.115 | 0 |
| 1 | 512 | 1 | 2692 | 117.565 | 316485 | 10.159 | 59.799 | 0 |
| 1 | 512 | 2 | 2329 | 115.523 | 269052 | 9.933 | 78.368 | 0 |
| 1 | 512 | 3 | 2768 | 118.597 | 328276 | 10.086 | 55.712 | 0 |
| 1 | 1024 | 1 | 2992 | 117.828 | 352541 | 12.229 | 116.758 | 0 |
| 1 | 1024 | 2 | 3168 | 119.390 | 378226 | 12.668 | 101.916 | 0 |
| 1 | 1024 | 3 | 3020 | 118.659 | 358349 | 12.277 | 113.164 | 0 |

**Batch 1: database-full-load throughput comparison unavailable.** both paths must independently demonstrate sustained database CPU saturation and a verified next-level throughput plateau; increase concurrency or isolate client/Weir resources; I/O/network-bound saturation needs additional device/link capacity evidence.

Best verified business QPS within this ladder: direct 654.9 (1024 workers), Weir 6038.7 (1024 workers), observed change +822.03%. This is a measured business-throughput comparison, not a maximum-database-capacity claim.

Observed single-request business performance at matched client concurrency (independent of the database-capacity qualification):

| Workers | Direct QPS | Weir QPS | Change | Direct p50/p95/p99 ms | Weir p50/p95/p99 ms |
| ---: | ---: | ---: | ---: | --- | --- |
| 128 | 444.9 | 3502.1 | +687.12% | 196.607 / 917.503 / 1179.647 | 24.575 / 106.495 / 122.879 |
| 512 | 654.6 | 5072.9 | +675.02% | 786.431 / 1048.575 / 1310.719 | 90.111 / 212.991 / 327.679 |
| 1024 | 654.9 | 6038.7 | +822.03% | 1572.863 / 1966.079 / 2359.295 | 163.839 / 327.679 / 425.983 |

These QPS and latency observations apply to this hardware and measured concurrency range. A business-throughput improvement can exist without demonstrating the maximum database capacity. An underfull database or missing next-level plateau keeps the database-capacity comparison unavailable.

Aggregation evidence: the JSON records one business request per record, Execute RPC counts, adapter invocation counts, average adapter batch and its cumulative histogram, and RPCs per adapter invocation. An adapter invocation is not necessarily one physical database wire command. MongoDB physical find/update/bulkWrite/getMore/killCursors/commitTransaction/abortTransaction deltas come from owned serverStatus at timed boundaries; missing counters remain unavailable. Elasticsearch has no equivalent physical HTTP-command counter. Every child PID, configured native pool limit, final revision ranges, exit result and sampled CPU/RSS is retained; coordinator sampling CPU is excluded from business-client CPU.

The JSON retains before/after raw public Weir metrics and their observed deltas, every resource sample, monitor failures, raw cumulative database/container I/O and network counters, CPU quota/host core denominator, and client/Weir cumulative CPU. Docker CPU uses cumulative Engine usage and read timestamps across each entire sampling interval, never CLI instantaneous percentages. Both interval endpoints must succeed; missing intervals reduce full-run coverage. Samples include monitoring traffic and background database work. Native ps CPU has platform-dependent clock resolution. Native databases share the host CPU budget with the client and Weir. Disk/network utilization or capacity is not inferred from byte counters. A plateau without sustained database CPU saturation is not a database-full-load result. Startup/discovery/reset/postflight and warmup are excluded from throughput; all in-flight completion and validation is included.

Resource observation schema 2 additionally retains bounded Linux host CPU ticks (busy, idle, iowait and steal, without double-counted guest ticks), CPU/IO/memory pressure, the sampler's allowed CPU list and runtime parallelism, Docker cumulative throttling counters, fixed sampled Store queue/execution gauges, and projected Search write-pool/indexing-pressure/GC statistics. Host/device evidence includes other runner work; sampler affinity is not a promise that all child processes have that affinity. Missing or unsupported fields remain explicitly unavailable. Pure Search stages retain before/after effective index settings and owned-index indexing/refresh/merge/flush/translog statistics, with explicit 1s refresh and request durability. Lucene flush statistics are not counts or timings of per-request translog fsync. No added metric alone establishes database or storage capacity.
