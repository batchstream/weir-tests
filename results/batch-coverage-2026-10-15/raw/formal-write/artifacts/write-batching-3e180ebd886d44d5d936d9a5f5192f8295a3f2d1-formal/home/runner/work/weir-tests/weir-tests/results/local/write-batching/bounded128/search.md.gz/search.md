# Database saturation comparison

Backend **search**. Started 2026-10-15T15:21:14.237254591Z.

independent OS client processes send one record per native call or streaming SDK RPC; native FindOne/ReplaceOne or single-ID mget/PUT; no client aggregation; worker-owned disjoint IDs; common phase barriers and unchanged pools across warmup and measurement; alternating AB/BA; latency is each business request including validation, queueing and any server aggregation; independent persisted postflight; sustained database CPU requires >=5 intervals, >=80% measurement coverage, mean CPU>=threshold and CPU>=threshold during >=80% measurement duration in every round, plus <=10% next-level throughput gain.

Warmup 1m0s and measurement 1m0s per path/stage, 3 paired rounds, requested writes 100%.

Complete business-request budget for both paths: 10s.

4 independent OS client processes. Each worker sends one business request containing one record, waits for its acknowledged result, and validates it. p50/p95/p99 describe individual requests; histograms are pooled rather than averaging process quantiles.

| Batch | Workers | Round | Path | Read | Write | Success | Errors/unknown | Ops/s | p95 call ms | DB CPU budget % | Full CPU time % | Sampling coverage % | Verified |
| ---: | ---: | ---: | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | --- |
| 1 | 128 | 1 | direct | 0 | 101545 | 101545 | 0 | 1690.6 | 122.879 | 73.6 | 16.4 | 99.7 | true |
| 1 | 128 | 1 | weir | 0 | 364580 | 364580 | 0 | 6075.0 | 32.767 | 34.1 | 3.6 | 99.5 | true |
| 1 | 128 | 2 | direct | 0 | 110097 | 110097 | 0 | 1832.8 | 81.919 | 65.9 | 0.0 | 98.9 | true |
| 1 | 128 | 2 | weir | 0 | 362445 | 362445 | 0 | 6039.5 | 32.767 | 34.1 | 1.8 | 99.9 | true |
| 1 | 128 | 3 | direct | 0 | 105947 | 105947 | 0 | 1763.7 | 81.919 | 64.8 | 0.0 | 98.8 | true |
| 1 | 128 | 3 | weir | 0 | 368601 | 368601 | 0 | 6142.1 | 32.767 | 31.8 | 3.6 | 99.6 | true |
| 1 | 512 | 1 | direct | 0 | 110582 | 110582 | 0 | 1835.0 | 327.679 | 61.8 | 0.0 | 98.6 | true |
| 1 | 512 | 1 | weir | 0 | 433773 | 433773 | 0 | 7226.4 | 122.879 | 30.6 | 1.8 | 98.7 | true |
| 1 | 512 | 2 | direct | 0 | 109632 | 109632 | 0 | 1819.0 | 327.679 | 62.5 | 0.0 | 98.6 | true |
| 1 | 512 | 2 | weir | 0 | 436699 | 436699 | 0 | 7273.8 | 114.687 | 30.9 | 1.8 | 98.5 | true |
| 1 | 512 | 3 | direct | 0 | 112600 | 112600 | 0 | 1868.7 | 327.679 | 64.0 | 0.0 | 98.6 | true |
| 1 | 512 | 3 | weir | 0 | 443241 | 443241 | 0 | 7382.7 | 114.687 | 30.3 | 1.9 | 98.3 | true |

Measured Weir adapter and streaming RPC evidence (warmup, reset and postflight excluded):

| Batch | Workers | Round | Adapter invocations | Mean adapter batch | Execute RPCs | Queue mean ms | Adapter mean ms | Rejections |
| ---: | ---: | ---: | ---: | ---: | --- | ---: | ---: | ---: |
| 1 | 128 | 1 | 8975 | 40.622 | 364580 | 3.265 | 8.451 | 0 |
| 1 | 128 | 2 | 8989 | 40.321 | 362445 | 3.270 | 8.435 | 0 |
| 1 | 128 | 3 | 8994 | 40.983 | 368601 | 3.277 | 8.249 | 0 |
| 1 | 512 | 1 | 5850 | 74.149 | 433773 | 7.479 | 24.284 | 0 |
| 1 | 512 | 2 | 5937 | 73.555 | 436699 | 7.369 | 22.746 | 0 |
| 1 | 512 | 3 | 6013 | 73.714 | 443241 | 7.229 | 21.960 | 0 |

**Batch 1: database-full-load throughput comparison unavailable.** both paths must independently demonstrate sustained database CPU saturation and a verified next-level throughput plateau; increase concurrency or isolate client/Weir resources; I/O/network-bound saturation needs additional device/link capacity evidence.

Best verified business QPS within this ladder: direct 1840.9 (512 workers), Weir 7294.3 (512 workers), observed change +296.23%. This is a measured business-throughput comparison, not a maximum-database-capacity claim.

Observed single-request business performance at matched client concurrency (independent of the database-capacity qualification):

| Workers | Direct QPS | Weir QPS | Change | Direct p50/p95/p99 ms | Weir p50/p95/p99 ms |
| ---: | ---: | ---: | ---: | --- | --- |
| 128 | 1762.4 | 6085.6 | +245.31% | 73.727 / 90.111 / 147.455 | 20.479 / 32.767 / 40.959 |
| 512 | 1840.9 | 7294.3 | +296.23% | 294.911 / 327.679 / 393.215 | 73.727 / 114.687 / 147.455 |

These QPS and latency observations apply to this hardware and measured concurrency range. A business-throughput improvement can exist without demonstrating the maximum database capacity. An underfull database or missing next-level plateau keeps the database-capacity comparison unavailable.

Aggregation evidence: the JSON records one business request per record, Execute RPC counts, adapter invocation counts, average adapter batch and its cumulative histogram, and RPCs per adapter invocation. An adapter invocation is not necessarily one physical database wire command. MongoDB physical find/update/bulkWrite/getMore/killCursors/commitTransaction/abortTransaction deltas come from owned serverStatus at timed boundaries; missing counters remain unavailable. Elasticsearch has no equivalent physical HTTP-command counter. Every child PID, configured native pool limit, final revision ranges, exit result and sampled CPU/RSS is retained; coordinator sampling CPU is excluded from business-client CPU.

The JSON retains before/after raw public Weir metrics and their observed deltas, every resource sample, monitor failures, raw cumulative database/container I/O and network counters, CPU quota/host core denominator, and client/Weir cumulative CPU. Docker CPU uses cumulative Engine usage and read timestamps across each entire sampling interval, never CLI instantaneous percentages. Both interval endpoints must succeed; missing intervals reduce full-run coverage. Samples include monitoring traffic and background database work. Native ps CPU has platform-dependent clock resolution. Native databases share the host CPU budget with the client and Weir. Disk/network utilization or capacity is not inferred from byte counters. A plateau without sustained database CPU saturation is not a database-full-load result. Startup/discovery/reset/postflight and warmup are excluded from throughput; all in-flight completion and validation is included.
